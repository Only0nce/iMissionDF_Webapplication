#!/usr/bin/env python3
# attctl.py (GPIO-SS MODE)
#
# SC18IS606: Force SS0/SS1/SS2 to GPIO and use them as PE43711 LE lines (manual latch)
# - Enable SS as GPIO:  F6h
# - Configure SS GPIO:  F7h (push-pull)
# - Write SS GPIO:      F4h
# - SPI clock/data still generated via SPI write Function ID (we use 0x01 as "SPI TX trigger")
#
# PE43711:
# - attenuation word = 4 * dB (0..127), D7=0
# - LSB-first => need bit-reverse because SC18 outputs MSB-first
# - Latch only on LE pulse (we do GPIO pulse)

import argparse
import json
import sys
import time
from smbus2 import SMBus, i2c_msg


# -----------------------------
# Low-level SC18IS606 bridge (SS as GPIO)
# -----------------------------
class SC18IS606:
    REG_CONFIG = 0xF0  # SPI config
    CMD_GPIO_WRITE  = 0xF4
    CMD_GPIO_ENABLE = 0xF6
    CMD_GPIO_CONFIG = 0xF7

    GPIO_INPUT     = 0b00
    GPIO_PUSHPULL  = 0b01
    GPIO_OPENDRAIN = 0b11

    def __init__(self, bus_num: int, i2c_addr: int):
        self.bus_num = bus_num
        self.addr = i2c_addr
        self.bus = SMBus(bus_num)
        self._init_chip_gpio_ss()

    def _init_chip_gpio_ss(self):
        # SPI Mode 0, MSB-first
        self.bus.write_byte_data(self.addr, self.REG_CONFIG, 0x00)

        # Enable SS0/SS1/SS2 as GPIO (bit0..2)
        # 1 = SS pin acts as GPIO instead of SS
        self.bus.write_byte_data(self.addr, self.CMD_GPIO_ENABLE, 0x07)

        # Configure SS0/SS1/SS2 as push-pull outputs (2-bit per SS)
        # F7h bits: [1:0]=SS0, [3:2]=SS1, [5:4]=SS2
        cfg = (self.GPIO_PUSHPULL << 0) | (self.GPIO_PUSHPULL << 2) | (self.GPIO_PUSHPULL << 4)
        self.bus.write_byte_data(self.addr, self.CMD_GPIO_CONFIG, cfg)

        # Default: all LE low (สำคัญมาก)
        self.gpio_write(0, 0, 0)
        time.sleep(0.005)

    def gpio_write(self, ss0: int, ss1: int, ss2: int):
        data = (1 if ss0 else 0) | ((1 if ss1 else 0) << 1) | ((1 if ss2 else 0) << 2)
        self.bus.write_byte_data(self.addr, self.CMD_GPIO_WRITE, data)

    def le_all_low(self):
        self.gpio_write(0, 0, 0)

    def le_pulse(self, ss_index: int, t_high_s: float = 5e-6):
        # Pulse only one LE: 0 -> 1 -> 0
        if ss_index not in (0, 1, 2):
            raise ValueError("ss_index must be 0..2")
        self.le_all_low()
        time.sleep(1e-6)
        if ss_index == 0:
            self.gpio_write(1, 0, 0)
        elif ss_index == 1:
            self.gpio_write(0, 1, 0)
        else:
            self.gpio_write(0, 0, 1)
        time.sleep(t_high_s)
        self.le_all_low()
        time.sleep(1e-6)

    def spi_tx(self, data_bytes):
        """
        Generate SPI clocks/data on MOSI/SCK.
        NOTE:
        - We still must send a "Function ID" byte per datasheet SPI write (01h..07h).
        - Even if SS pins are GPIO, SC18 still performs SPI shifting for the message.
        - We use 0x01 as a consistent "TX trigger" (doesn't matter which SS in GPIO mode).
        """
        if not data_bytes:
            return

        # Use raw i2c write to avoid SMBus 32-byte limit if needed
        # Frame: [FunctionID][DATA...]
        function_id = 0x01
        payload = [function_id] + list(data_bytes)
        msg = i2c_msg.write(self.addr, payload)
        self.bus.i2c_rdwr(msg)

    def spi_write_and_latch(self, le_ss_index: int, data_bytes):
        # Ensure no latch while shifting
        self.le_all_low()
        time.sleep(1e-6)

        # Shift data (all devices on shared MOSI/SCK see it, but LE is low so they shouldn't latch yet)
        self.spi_tx(data_bytes)
        time.sleep(1e-6)

        # Latch only selected attenuator
        self.le_pulse(le_ss_index)


# -----------------------------
# PE43711 attenuator (bit-reverse + latch pulse)
# -----------------------------
class PE43711:
    def __init__(self, bridge: SC18IS606, le_ss_index: int):
        self.bridge = bridge
        self.le = le_ss_index

    @staticmethod
    def _bit_reverse8(x: int) -> int:
        x &= 0xFF
        x = ((x & 0xF0) >> 4) | ((x & 0x0F) << 4)
        x = ((x & 0xCC) >> 2) | ((x & 0x33) << 2)
        x = ((x & 0xAA) >> 1) | ((x & 0x55) << 1)
        return x & 0xFF

    @staticmethod
    def _round_to_step(db: float) -> float:
        return round(float(db) / 0.25) * 0.25

    def set_db(self, db: float):
        if db < 0.0 or db > 31.75:
            raise ValueError("dB out of range (0..31.75)")

        db = self._round_to_step(db)

        # Datasheet: Attenuation word = 4 * dB, D7=0
        word = int(round(db * 4.0)) & 0x7F

        # PE43711 expects LSB-first; SC18 outputs MSB-first => reverse bits
        spi_byte = self._bit_reverse8(word)

        # Shift then latch only this one
        self.bridge.spi_write_and_latch(self.le, [spi_byte])


# -----------------------------
# Locked mapping for your board (U31/U32/U33)
# -----------------------------
def build_att_map(bus_num: int = None, *, bus_id: int = None):
    if bus_num is None:
        if bus_id is None:
            raise TypeError("build_att_map(): missing bus number (bus_num or bus_id)")
        bus_num = bus_id

    # Addresses found: 0x29, 0x2A, 0x2C
    u31 = SC18IS606(bus_num, 0x29)
    u32 = SC18IS606(bus_num, 0x2A)
    u33 = SC18IS606(bus_num, 0x2C)

    return {
        1: PE43711(u31, 2),
        2: PE43711(u31, 1),
        3: PE43711(u31, 0),
        4: PE43711(u32, 2),
        5: PE43711(u32, 0),
        6: PE43711(u33, 2),
        7: PE43711(u33, 1),
        8: PE43711(u33, 0),
    }



def clamp_to_step(db: float) -> float:
    return round(float(db) / 0.25) * 0.25


def set_one(att_map, idx: int, db: float, verbose=True):
    if idx not in att_map:
        raise ValueError(f"ATT index invalid: {idx} (must be 1..8)")
    db = clamp_to_step(db)
    att_map[idx].set_db(db)
    if verbose:
        print(f"ATT{idx} <- {db:.2f} dB")


def set_all(att_map, db: float, verbose=True):
    db = clamp_to_step(db)
    for i in range(1, 9):
        att_map[i].set_db(db)
    if verbose:
        print(f"ALL ATT <- {db:.2f} dB")


def apply_json(att_map, payload, verbose=True):
    if not isinstance(payload, dict):
        raise ValueError("JSON must be an object")

    if "all" in payload:
        set_all(att_map, float(payload["all"]), verbose=verbose)

    if "att" in payload:
        obj = payload["att"]
        if not isinstance(obj, dict):
            raise ValueError('"att" must be an object {"1":db,...}')
        for k, v in obj.items():
            set_one(att_map, int(k), float(v), verbose=verbose)


def dump_map():
    print("GPIO-SS mode (SS pins used as LE):")
    print("  U31 @ 0x29: SS0=ATT3_LE, SS1=ATT2_LE, SS2=ATT1_LE")
    print("  U32 @ 0x2A: SS0=ATT5_LE, SS1=NC,      SS2=ATT4_LE")
    print("  U33 @ 0x2C: SS0=ATT8_LE, SS1=ATT7_LE, SS2=ATT6_LE")
    print("")
    print("ATT -> (U, I2C, LE(SS))")
    print("  ATT1 -> (U31, 0x29, SS2)")
    print("  ATT2 -> (U31, 0x29, SS1)")
    print("  ATT3 -> (U31, 0x29, SS0)")
    print("  ATT4 -> (U32, 0x2A, SS2)")
    print("  ATT5 -> (U32, 0x2A, SS0)")
    print("  ATT6 -> (U33, 0x2C, SS2)")
    print("  ATT7 -> (U33, 0x2C, SS1)")
    print("  ATT8 -> (U33, 0x2C, SS0)")


def main():
    p = argparse.ArgumentParser(
        description="attctl.py (GPIO-SS MODE): SC18IS606 SS pins as GPIO for PE43711 LE",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("--bus", type=int, default=2, help="I2C bus number (default: 2)")
    p.add_argument("--all", type=float, default=None, help="Set all attenuators to this dB (0..31.75)")
    p.add_argument("--att", action="append", nargs=2, metavar=("N", "DB"),
                   help="Set one attenuator: --att 3 12.5  (N=1..8). Can repeat.")
    p.add_argument("--json", type=str, default=None,
                   help='JSON control: e.g. \'{"all":15}\' or \'{"att":{"1":10,"2":0}}\'')
    p.add_argument("--quiet", action="store_true", help="No print")
    p.add_argument("--dump-map", action="store_true", help="Show locked mapping and exit")
    args = p.parse_args()

    if args.dump_map:
        dump_map()
        return 0

    verbose = (not args.quiet)
    att_map = build_att_map(args.bus)

    did = False
    if args.all is not None:
        set_all(att_map, args.all, verbose=verbose)
        did = True

    if args.att:
        for n_str, db_str in args.att:
            set_one(att_map, int(n_str), float(db_str), verbose=verbose)
        did = True

    if args.json:
        payload = json.loads(args.json)
        apply_json(att_map, payload, verbose=verbose)
        did = True

    if not did:
        p.print_help()
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
