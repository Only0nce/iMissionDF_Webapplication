#!/usr/bin/env python3
# doa_music_server_dma.py
#
# IQ 5ch -> DOA(MUSIC UCA) + optional FFT spectrum -> TCP JSON
# + Support changing RF center frequency via external MTS+NCO tool (rfsoc_adc_mts --setfreq)
# + RF clamp range: 10 MHz .. 3 GHz
#
# Commands from client (JSON line, newline-terminated):
#   {"menuID":"setSpectrumEnable","enable":true/false,"needAck":true}
#   {"menuID":"setDoaEnable","enable":true/false,"needAck":true}
#   {"menuID":"setStreamEnable","enable":true/false,"needAck":true}
#   {"menuID":"setFftConfig","fft_points":4096,"fft_downsample":2,"needAck":true}
#   {"menuID":"setAdcChannel","channel":0,"needAck":true}              # FFT channel
#   {"menuID":"setTxHz","hz":10.0,"needAck":true}
#   {"menuID":"setTxIntervalMs","ms":100,"needAck":true}
#   {"menuID":"setDoaTargetOffsetHz","offset_hz":50000,"needAck":true}
#   {"menuID":"setDoaBwHz","bw_hz":2000,"needAck":true}
#   {"menuID":"setDoaPowerThresholdDb","th_db":-65.0,"needAck":true}
#   {"menuID":"setDoaAlgorithm","algo":"uca_rb_music"|"uca_esprit"|"music_1d_uca","needAck":true}
#   {"menuID":"getState","needAck":true}
#
#   --- NCO / frequency control (MTS first, then NCO + post delay) ---
#   {"menuID":"setFrequencyHz","freq_hz":133600000,"update_en":63,"needAck":true}
#   {"menuID":"setFcHz","fc_hz":133600000,"needAck":true}   # software-only labeling
#
#   --- Phase debug over socket (always enabled by default) ---
#   {"menuID":"setPhaseDebug","enable":true,"interval_ms":1000,"ref_ch":0,"needAck":true}
#
# Notes:
# - IQ device: /dev/iq_capture5 (read BLOCK_BYTES per frame)
# - DOA: MUSIC 1D UCA (internal) or doa_py algorithms if installed
# - FFT: "rf spectrum" of selected channel at abs freq = Fc + baseband bins
#
#   --- ConnMan (IP / Link) control ---
#   {"menuID":"setIpConfig","ifname":"end0",
#    "ip":"192.168.10.50","netmask":"255.255.255.0",
#    "gateway":"192.168.10.254",
#    "dns1":"8.8.8.8","dns2":"1.1.1.1",
#    "needAck":true}
#
#   {"menuID":"getLinkState","ifname":"end0","needAck":true}
#   {"menuID":"getLinkState","ifname":"end1","needAck":true}
#
#   --- Link event pushed by server (no request needed) ---
#   {"menuID":"LinkState","timestamp":"...","ifname":"end0","link_up":true/false}
#   {"menuID":"LinkState","timestamp":"...","ifname":"end1","link_up":true/false}

import socket
import json
from datetime import datetime
import select
import time
from typing import Dict, Any, Optional, Tuple, List
import warnings
import numpy as np
import inspect
import math
import threading
import subprocess
import re
import fcntl
import struct
import os

# --- Network IP config via connmanctl ---
try:
    from connman_driver import ConnmanManager, LinkMonitor, ConnmanError
    _CONNMAN_OK = True
except Exception as _e:
    ConnmanManager = None
    LinkMonitor = None
    ConnmanError = Exception
    _CONNMAN_OK = False
    print(f"[WARN] ConnMan driver not available: {_e}")

# =======================================================
# Optional: RF attenuator AGC (PE43711) per-channel (CH1..CH5)
# - Safe optional import: if modules are missing, server still runs (AGC disabled)
# =======================================================
_ATT_AGC_OK = False
AttAgc = None
build_att_map = None
_G_AGC_PER_CH = None  # list[AttAgc] or None
_G_ATT_MAP = None     # dict[int, PE43711] or None

# ---- Scanner attenuator (ATT #7) ----
SCANNER_ATT_INDEX = 7
DEFAULT_SCANNER_ATT_DB = 0.0
try:
    from att_agc import AttAgc as _AttAgc
    from attctl import build_att_map as _build_att_map
    AttAgc = _AttAgc
    build_att_map = _build_att_map
    _ATT_AGC_OK = True
    print("[INFO] RF ATT AGC modules found.")
except Exception as _e:
    _ATT_AGC_OK = False
    print(f"[WARN] RF ATT AGC disabled (missing att_agc/attctl): {_e}")

# =======================================================
# Optional: use doa_py implementations (UCA-RB-MUSIC / UCA-ESPRIT)
# If doa_py is not installed, we fall back to the internal MUSIC implementation.
# =======================================================
_DOA_PY_OK = False
_doa_py_arrays = None
_doa_py_algo = None


# ================== CONFIG ==================

IQ_DEV_PATH      = "/dev/iq_capture5"

NUM_CH           = 5
WORDS_PER_BEAT   = 8
NUM_SAMPLES      = 4096
BYTES_PER_SAMPLE = 32
BLOCK_BYTES      = NUM_SAMPLES * BYTES_PER_SAMPLE  # 131072

FS               = 240e3          # baseband sample rate after decimation
DEFAULT_FC_HZ    = 130e6          # RF center used by MUSIC/FFT labeling
UCA_RADIUS_M     = 0.8
NUM_SIGNAL       = 1
C_MPS            = 3.0e8

THETA_MIN_DEG    = 0.0
THETA_MAX_DEG    = 360.0
THETA_STEP_DEG   = 1.0
_theta_grids_deg = np.arange(THETA_MIN_DEG, THETA_MAX_DEG, THETA_STEP_DEG, dtype=np.float32)

# FFT
FFT_POINTS       = 4096
FFT_DOWNSAMPLE   = 2

# IQ layout
# If your AXI word is {Q[31:16], I[15:0]} then IQ_SWAP=False
# If your AXI word is {I[31:16], Q[15:0]} then IQ_SWAP=True
DEFAULT_IQ_SWAP  = True

# TCP server
TCP_HOST         = "0.0.0.0"
TCP_PORT         = 5555

# ---- DEFAULT STATES ----
DEFAULT_STREAM_ENABLED   = True
DEFAULT_DOA_ENABLED      = True
DEFAULT_SPECTRUM_ENABLED = False   # default ปิด FFT
DEFAULT_DOA_ALGO         = "music_1d_uca"   # or "uca_rb_music" | "uca_esprit"
DEFAULT_FFT_POINTS       = 1024
DEFAULT_FFT_DOWNSAMPLE   = 1
DEFAULT_FFT_CHANNEL      = 0

# ---- RATE LIMIT ----
DEFAULT_TX_HZ = 10.0
MIN_TX_HZ     = 0.2
MAX_TX_HZ     = 60.0
IDLE_SLEEP_SEC = 0.02

# ---- DOA TARGET IN-BAND ----
DEFAULT_DOA_BW_HZ     = 20000.0  # DOA BW (Hz)
DEFAULT_FIR_TAPS      = 129      # odd taps
DEFAULT_DOA_OFFSET_HZ = DEFAULT_DOA_BW_HZ     # offset from Fc

# ---- SIGNAL PRESENT GATE (dB, based on FFT peak inside band) ----
DEFAULT_GATE_TH_DB    = -100.0   # tune based on your noise floor

# ===== Frequency clamp (RF range) =====
MIN_RF_HZ = 10_000_000      # 10 MHz
MAX_RF_HZ = 3_000_000_000   # 3 GHz

# ================== RF BAND WS (service) ==================
RF_BAND_WS_HOST = "127.0.0.1"
RF_BAND_WS_PORT = 8765
RF_BAND_APPLY_COOLDOWN_SEC = 0.25  # กันเปลี่ยนถี่เกิน

# ================== RF MTS + NCO TOOL (IMPORTANT) ==================
# ใช้ binary ตัวเดียวทำ "MTS/SYSREF -> (หน่วง) -> NCO apply"
# คุณต้องมี rfsoc_adc_mts ที่รองรับ flags ชุดนี้
DEFAULT_RF_MTS_BIN = "/usr/local/bin/rfsoc_adc_mts"
DEFAULT_MTS_TILES = "224,225,226"
DEFAULT_GPIOCHIP = "3"
DEFAULT_LMK_RESET = "79"
DEFAULT_LMK_SYNC = "78"
DEFAULT_SPI_DEV = "/dev/spidev2.0"
DEFAULT_DO_LMK_INIT = "0"
DEFAULT_SYSREF_SHOTS = "2"
DEFAULT_SYSREF_PULSE = "1"
DEFAULT_SYSREF_REPEAT = "2"
DEFAULT_SYSREF_DELAY_US = "2000"

DEFAULT_NCO_BASE_STR = "0x80080000"
DEFAULT_NCO_FS_STR   = "1228800000"
DEFAULT_UPDATE_EN = 0x3F  # 6 slice mask default
DEFAULT_NCO_PHASE = 0
DEFAULT_NCO_RST   = 0
DEFAULT_POST_MTS_DELAY_MS = 1000

# ================== OLED (optional) ==================
try:
    from oled_df_driver import OledSpiDF
    _OLED_OK = True
except Exception as _e:
    OledSpiDF = None
    _OLED_OK = False
    print(f"[WARN] OLED disabled (missing oled_df_driver): {_e}")

# ================== OTA STATUS LISTENER (UDS server) ==================
# df_ota_agent pushes OtaStatus JSON lines here:
#   /run/doa-ota-status.sock
DF_VERSION_FILE = "/etc/df_version.json"

def load_sw_version():
    info = {
        "version": "unknown",
        "deploy_date": ""
    }
    try:
        if os.path.exists(DF_VERSION_FILE):
            with open(DF_VERSION_FILE, "r", encoding="utf-8") as f:
                j = json.load(f)
            if isinstance(j, dict):
                info["version"] = str(j.get("version", info["version"]))
                info["deploy_date"] = str(j.get("deploy_date", ""))
    except Exception:
        pass
    return info

DOA_OTA_STATUS_SOCK = "/run/doa-ota-status.sock"
def _ota_status_listener_thread(state: dict):
    # cleanup old socket
    try:
        if os.path.exists(DOA_OTA_STATUS_SOCK):
            os.remove(DOA_OTA_STATUS_SOCK)
    except Exception:
        pass

    os.makedirs(os.path.dirname(DOA_OTA_STATUS_SOCK), exist_ok=True)

    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    srv.bind(DOA_OTA_STATUS_SOCK)
    os.chmod(DOA_OTA_STATUS_SOCK, 0o666)
    srv.listen(5)

    rx_map = {}  # conn -> bytearray
    print(f"[INFO] OTA status listener started: {DOA_OTA_STATUS_SOCK}")

    def _store_ota(msg: dict):
        # agent sends: state/pct/msg
        nowm = time.monotonic()
        stage = str(msg.get("state", msg.get("stage", ""))).strip()
        pct = msg.get("pct", msg.get("progress", None))
        text = str(msg.get("msg", msg.get("message", ""))).strip()

        state["_ota"] = {
            "stage": stage,
            "progress": pct,
            "message": text,
            "ok": bool(msg.get("ok", True)),
            "reboot_required": bool(msg.get("reboot_required", False)),
            "version": str(msg.get("version", "")),
            "deploy_date": str(msg.get("deploy_date", "")),
            "ts_monotonic": nowm,
            "raw": msg,  # optional debug
        }

        # ✅ ใส่ log เพื่อยืนยันว่ามี msg เข้ามาจริง
        # (เอาไว้ก่อน พอชัวร์แล้วค่อยปิด)
        try:
            pdisp = "-" if pct is None else str(pct)
            print(f"[OTA] {stage} {pdisp}% {text}")
        except Exception:
            pass

    while True:
        try:
            conn, _ = srv.accept()
            conn.settimeout(0.5)
            rx_map[conn] = bytearray()
        except Exception:
            time.sleep(0.1)
            continue

        start_t = time.monotonic()
        while True:
            if (time.monotonic() - start_t) > 5.0:
                break
            try:
                b = conn.recv(4096)
                if not b:
                    break
                rx_map[conn].extend(b)

                while True:
                    nl = rx_map[conn].find(b"\n")
                    if nl < 0:
                        break
                    line = rx_map[conn][:nl].strip()
                    del rx_map[conn][:nl + 1]
                    if not line:
                        continue

                    try:
                        msg = json.loads(line.decode("utf-8", errors="replace"))
                    except Exception:
                        continue

                    if isinstance(msg, dict) and msg.get("event") == "OtaStatus":
                        _store_ota(msg)

            except socket.timeout:
                continue
            except Exception:
                break

        try:
            conn.close()
        except Exception:
            pass
        rx_map.pop(conn, None)



def start_ota_status_listener(state: dict):
    state.setdefault("_ota_status", None)
    state.setdefault("_ota_status_ts", 0.0)
    t = threading.Thread(target=_ota_status_listener_thread, args=(state,), daemon=True)
    t.start()
    print(f"[INFO] OTA status listener started: {DOA_OTA_STATUS_SOCK}")

# ================== PHASE DEBUG (send via socket, not console) ==================

def calc_phase_debug(X: np.ndarray, ref_ch: int = 0) -> Dict[str, Any]:
    """
    คืนค่าข้อมูล phase/coherence/rms เทียบกับ ref_ch
    X: complex ndarray shape (M, L)
    """
    M, L = X.shape
    ref_ch = max(0, min(M - 1, int(ref_ch)))
    xref = X[ref_ch]

    p = np.mean((X.real * X.real + X.imag * X.imag), axis=1) + 1e-30
    pref = float(np.mean((xref.real * xref.real + xref.imag * xref.imag)) + 1e-30)

    rms = np.sqrt(p)
    rms_dbfs = (20.0 * np.log10(rms + 1e-30)).astype(np.float32)

    phase_deg = np.zeros((M,), dtype=np.float32)
    coh = np.ones((M,), dtype=np.float32)

    for i in range(M):
        if i == ref_ch:
            phase_deg[i] = 0.0
            coh[i] = 1.0
            continue
        c = np.mean(X[i] * np.conj(xref))
        phase_deg[i] = float(np.degrees(np.angle(c)))
        coh[i] = float(np.abs(c) / (math.sqrt(float(p[i]) * pref) + 1e-30))

    return {
        "ref_ch": int(ref_ch),
        "phase_deg": phase_deg.tolist(),
        "coh":       coh.tolist(),
        "rms_dbfs":  rms_dbfs.tolist(),
        "num_ch":    int(M),
        "num_snap":  int(L),
    }


# ================== doa_py (optional) ==================

def _try_import_doa_py() -> bool:
    global _DOA_PY_OK, _doa_py_arrays, _doa_py_algo
    if _DOA_PY_OK:
        return True
    try:
        from doa_py import arrays as _arrays
        from doa_py import algorithm as _algo
        _doa_py_arrays = _arrays
        _doa_py_algo = _algo
        _DOA_PY_OK = True
        print("[INFO] doa_py found: enabling UCA-RB-MUSIC / UCA-ESPRIT backend.")
        return True
    except Exception as e:
        print(f"[WARN] doa_py not available ({e}). Using internal MUSIC backend only.")
        _DOA_PY_OK = False
        _doa_py_arrays = None
        _doa_py_algo = None
        return False


def _build_doa_py_uca(m: int, radius_m: float):
    """Create doa_py UniformCircularArray with best-effort argument mapping (API may vary by version)."""
    if not _try_import_doa_py():
        return None
    UCA = getattr(_doa_py_arrays, "UniformCircularArray", None)
    if UCA is None:
        return None

    sig = None
    try:
        sig = inspect.signature(UCA)
    except Exception:
        sig = None

    candidates = [
        {"m": m, "r": radius_m},
        {"m": m, "radius": radius_m},
        {"m": m, "rr": radius_m},
        {"m": m, "R": radius_m},
        {"m": m, "radius_m": radius_m},
    ]
    for kwargs in candidates:
        try:
            if sig is not None:
                filtered = {k: v for k, v in kwargs.items() if k in sig.parameters}
            else:
                filtered = kwargs
            if "m" not in filtered:
                filtered["m"] = m
            return UCA(**filtered)
        except TypeError:
            continue
        except Exception:
            continue

    try:
        return UCA(m, radius_m)
    except Exception:
        return None


def _doa_py_uca_rb_music(received_data: np.ndarray,
                         uca: Any,
                         fc_hz: float,
                         num_signal: int,
                         angle_grids_deg: np.ndarray):
    """
    Normalize to 4-tuple:
      doa_deg(list[float]), conf(list[float]), theta_grid_deg(np.ndarray), P_norm(np.ndarray)
    """
    if not _try_import_doa_py():
        return None
    try:
        fn = getattr(_doa_py_algo.music_based, "uca_rb_music", None)
        if fn is None:
            raise RuntimeError("doa_py uca_rb_music not found")

        az = np.asarray(angle_grids_deg, dtype=np.float32)
        el = np.asarray([0.0], dtype=np.float32)  # elevation=0 deg

        out = fn(received_data, num_signal, uca, float(fc_hz), az, el, "deg")

        theta_grid_deg = az
        P_norm = None

        if isinstance(out, np.ndarray):
            P = out
            if P.ndim == 2:
                P_norm = np.asarray(P[:, 0], dtype=np.float32)
            elif P.ndim == 1:
                P_norm = np.asarray(P, dtype=np.float32)
            else:
                raise ValueError(f"uca_rb_music ndarray invalid ndim={P.ndim}")

            k = int(np.argmax(P_norm))
            doa_deg = [float(theta_grid_deg[k])]
            peak = float(P_norm[k])
            mean = float(np.mean(P_norm)) + 1e-12
            ratio = peak / mean
            conf = [float(1.0 - np.exp(-0.25 * max(0.0, ratio - 1.0)))]
            return (doa_deg, conf, theta_grid_deg, P_norm)

        if isinstance(out, dict):
            doa_deg = out.get("doa_deg", out.get("doa", []))
            conf = out.get("confidence", out.get("conf", []))
            tg = out.get("theta_grid_deg", out.get("azimuth_grids", None))
            P = out.get("P_norm", out.get("spectrum", None))
            if tg is not None:
                theta_grid_deg = np.asarray(tg, dtype=np.float32)
            if P is not None:
                P = np.asarray(P)
                if P.ndim == 2:
                    P_norm = np.asarray(P[:, 0], dtype=np.float32)
                elif P.ndim == 1:
                    P_norm = np.asarray(P, dtype=np.float32)
            if P_norm is None:
                P_norm = np.zeros((theta_grid_deg.size,), dtype=np.float32)

            if isinstance(doa_deg, np.ndarray):
                doa_deg = doa_deg.astype(float).tolist()
            if isinstance(conf, np.ndarray):
                conf = conf.astype(float).tolist()
            if (not conf) and doa_deg:
                conf = [1.0] * len(doa_deg)
            return (doa_deg, conf, theta_grid_deg, P_norm)

        if isinstance(out, (tuple, list)):
            items = list(out)
            spec = None
            for it in items:
                if isinstance(it, np.ndarray) and it.ndim in (1, 2):
                    spec = it
                    break
            if spec is not None:
                if spec.ndim == 2:
                    P_norm = np.asarray(spec[:, 0], dtype=np.float32)
                else:
                    P_norm = np.asarray(spec, dtype=np.float32)
                k = int(np.argmax(P_norm))
                doa_deg = [float(theta_grid_deg[k])]
                peak = float(P_norm[k])
                mean = float(np.mean(P_norm)) + 1e-12
                ratio = peak / mean
                conf = [float(1.0 - np.exp(-0.25 * max(0.0, ratio - 1.0)))]
                return (doa_deg, conf, theta_grid_deg, P_norm)
            raise TypeError("uca_rb_music tuple/list but no ndarray spectrum found")

        raise TypeError(f"uca_rb_music returned unsupported type: {type(out)}")

    except Exception as e:
        print(f"[WARN] doa_py uca_rb_music failed: {e}")
        return None


def _doa_py_uca_esprit(received_data: np.ndarray,
                       uca: Any,
                       fc_hz: float,
                       num_signal: int):
    """
    Normalize to 4-tuple:
      doa_deg(list[float]), conf(list[float]), theta_grid_deg(None), P_norm(None)
    """
    if not _try_import_doa_py():
        return None
    try:
        fn = getattr(_doa_py_algo.esprit_based, "uca_esprit", None)
        if fn is None:
            fn = getattr(_doa_py_algo, "uca_esprit", None)
        if fn is None:
            raise RuntimeError("doa_py uca_esprit not found")

        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=RuntimeWarning,
                                    message=".*invalid value encountered in arccos.*")
            out = fn(received_data, num_signal, uca, float(fc_hz), "deg")

        def _sanitize(doa_list, conf_list):
            doa_arr = np.asarray(doa_list, dtype=np.float32).ravel()
            if conf_list is None or (isinstance(conf_list, (list, tuple, np.ndarray)) and len(conf_list) == 0):
                conf_arr = np.ones(doa_arr.size, dtype=np.float32)
            else:
                conf_arr = np.asarray(conf_list, dtype=np.float32).ravel()
                if conf_arr.size != doa_arr.size:
                    conf_arr = np.ones(doa_arr.size, dtype=np.float32)

            mask = np.isfinite(doa_arr)
            doa_arr = doa_arr[mask]
            conf_arr = conf_arr[mask]
            doa_deg = doa_arr.astype(float).tolist()
            conf = conf_arr.astype(float).tolist() if doa_deg else []
            return doa_deg, conf

        if isinstance(out, np.ndarray):
            doa_deg, conf = _sanitize(out, None)
            return (doa_deg, conf, None, None)

        if isinstance(out, (list, tuple)):
            if len(out) == 0:
                return ([], [], None, None)
            if len(out) == 2 and not isinstance(out[1], (str, bytes)):
                doa_deg, conf = _sanitize(out[0], out[1])
                return (doa_deg, conf, None, None)
            doa_deg, conf = _sanitize(out, None)
            return (doa_deg, conf, None, None)

        if isinstance(out, dict):
            doa_list = out.get("doa_deg", out.get("doa", []))
            conf_list = out.get("confidence", out.get("conf", []))
            doa_deg, conf = _sanitize(doa_list, conf_list)
            return (doa_deg, conf, None, None)

        raise TypeError(f"uca_esprit returned unsupported type: {type(out)}")

    except Exception as e:
        print(f"[WARN] doa_py uca_esprit failed: {e}")
        return None


# ================== NON-BLOCKING SEND HELPERS ==================

def _send_bytes_nonblock(conn: socket.socket,
                         payload: bytes,
                         *,
                         drop_if_busy: bool,
                         wait_timeout_sec: float = 0.05) -> bool:
    if not payload:
        return True
    view = memoryview(payload)
    total = len(payload)
    sent_total = 0
    while sent_total < total:
        try:
            n = conn.send(view[sent_total:])
            if n <= 0:
                return False
            sent_total += n
            continue
        except (BlockingIOError, InterruptedError):
            if drop_if_busy:
                return False
            _, w, _ = select.select([], [conn], [], wait_timeout_sec)
            if not w:
                return False
            continue
    return True


def _send_frame_drop(conn: socket.socket, payload_str: str) -> None:
    _send_bytes_nonblock(conn, payload_str.encode("utf-8"),
                         drop_if_busy=True, wait_timeout_sec=0.0)


def _send_control(conn: socket.socket, payload_str: str) -> bool:
    return _send_bytes_nonblock(conn, payload_str.encode("utf-8"),
                                drop_if_busy=False, wait_timeout_sec=0.05)


# ================== IQ DECODE ==================

def decode_iq_u32(raw_u32: np.ndarray, iq_swap: bool) -> np.ndarray:
    if raw_u32.size == 0:
        raise ValueError("IQ buffer is empty")

    total_beats = raw_u32.size // WORDS_PER_BEAT
    if total_beats == 0:
        raise ValueError("Not enough data for even 1 AXI beat")

    raw_u32 = raw_u32[:total_beats * WORDS_PER_BEAT]
    raw_u32 = raw_u32.reshape(total_beats, WORDS_PER_BEAT)

    ch_words = [raw_u32[:, i] for i in range(NUM_CH)]

    samples = []
    for w in ch_words:
        if iq_swap:
            i16 = ((w >> 16) & 0xFFFF).astype(np.int16)
            q16 = (w & 0xFFFF).astype(np.int16)
        else:
            i16 = (w & 0xFFFF).astype(np.int16)
            q16 = ((w >> 16) & 0xFFFF).astype(np.int16)

        i_f = i16.astype(np.float32) / 32768.0
        q_f = q16.astype(np.float32) / 32768.0
        samples.append(i_f + 1j * q_f)

    return np.stack(samples, axis=0).astype(np.complex64)  # (M, L)


def capture_block_from_fd(fd, block_bytes: int, iq_swap: bool) -> np.ndarray:
    buf = bytearray()
    while len(buf) < block_bytes:
        chunk = fd.read(block_bytes - len(buf))
        if not chunk:
            raise IOError("EOF while reading IQ device")
        buf.extend(chunk)
    raw_u32 = np.frombuffer(buf, dtype=np.uint32)
    return decode_iq_u32(raw_u32, iq_swap)


# ================== FIR / NARROWBAND ==================

def design_lowpass_fir(num_taps: int, cutoff_hz: float, fs_hz: float) -> np.ndarray:
    if num_taps < 17:
        num_taps = 17
    if num_taps % 2 == 0:
        num_taps += 1

    cutoff_hz = float(cutoff_hz)
    fs_hz = float(fs_hz)

    if cutoff_hz < 10.0:
        cutoff_hz = 10.0
    if cutoff_hz > 0.49 * fs_hz:
        cutoff_hz = 0.49 * fs_hz

    fc = cutoff_hz / fs_hz
    n = np.arange(num_taps) - (num_taps - 1) / 2.0

    h = 2.0 * fc * np.sinc(2.0 * fc * n)
    w = 0.54 - 0.46 * np.cos(2.0 * np.pi * np.arange(num_taps) / (num_taps - 1))
    h *= w
    h /= (np.sum(h) + 1e-12)

    return h.astype(np.float32)


def narrowband_extract(X: np.ndarray,
                       fs_hz: float,
                       offset_hz: float,
                       fir_taps: np.ndarray,
                       phase_acc_rad: float):
    M, L = X.shape
    Nt = fir_taps.size
    if L < (Nt + 8):
        return X, phase_acc_rad

    w = 2.0 * np.pi * float(offset_hz) / float(fs_hz)

    n = np.arange(L, dtype=np.float64)
    osc = np.exp(-1j * (phase_acc_rad + w * n)).astype(np.complex64)
    new_phase = (phase_acc_rad + w * L) % (2.0 * np.pi)

    Xmix = X * osc.reshape(1, L)

    outL = L - (Nt - 1)
    Xnb = np.empty((M, outL), dtype=np.complex64)

    h = fir_taps.astype(np.float32)
    for m in range(M):
        xr = np.convolve(Xmix[m].real.astype(np.float32), h, mode="valid")
        xi = np.convolve(Xmix[m].imag.astype(np.float32), h, mode="valid")
        Xnb[m] = xr.astype(np.float32) + 1j * xi.astype(np.float32)

    return Xnb, new_phase


# ============================================================
# Fast DOA (Arduino-style idea adapted):
# - After narrowband mixing+FIR, take complex mean per channel (phasor)
# - Scan Bartlett / matched beamformer over theta grid on UCA steering vector
# - Very fast and stable in LOS
# ============================================================

def uca_steering_vec(theta_deg: float, m: int, radius_m: float, fc_hz: float) -> np.ndarray:
    """UCA steering vector (azimuth-only, elevation=0).
    element angles: phi_m = 2π m / M, m=0..M-1
    a[m] = exp(-j*k*R*cos(theta - phi_m)), k = 2π f / c
    """
    theta = np.deg2rad(theta_deg)
    elem_phi = 2.0 * np.pi * np.arange(m, dtype=np.float64) / float(m)
    k = 2.0 * np.pi * float(fc_hz) / float(C_MPS)
    phase = -1j * k * float(radius_m) * np.cos(theta - elem_phi)
    return np.exp(phase).astype(np.complex64)


def _softmax_stable(x: np.ndarray, beta: float = 12.0) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    x = x - float(np.max(x))
    y = np.exp(beta * x)
    s = float(np.sum(y)) + 1e-30
    return (y / s).astype(np.float32)


def _extract_cross_phase_per_tone(
    X: np.ndarray,        # (M,L) complex
    fs_hz: float,
    tone_hz_list: List[float],
    ref_ch: int = 0,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    For each tone f_k, estimate cross-spectrum C_mk = mean( x_m * conj(x_ref) * exp(-j2π f_k n/fs) ).
    Returns:
      phase_mk: (M,K) in radians, wrapped [-pi,pi]
      weight_k: (K,)  tone strength weight (0..1) from |C_refref|
    """
    M, L = X.shape
    K = len(tone_hz_list)
    ref_ch = int(max(0, min(M - 1, ref_ch)))

    n = np.arange(L, dtype=np.float64)
    win = np.hanning(L).astype(np.float32)
    win = win / (float(np.sum(win)) + 1e-30)

    xref = X[ref_ch]
    phase_mk = np.zeros((M, K), dtype=np.float64)
    strength_k = np.zeros((K,), dtype=np.float64)

    for k, f in enumerate(tone_hz_list):
        w = 2.0 * np.pi * float(f) / float(fs_hz)
        osc = np.exp(-1j * (w * n)).astype(np.complex64)  # mix tone to 0Hz

        # reference auto (after mix) as a measure of tone presence
        rr = np.sum((xref * osc) * win)
        strength_k[k] = float(np.abs(rr))

        # cross phase per channel
        for m in range(M):
            cm = np.sum((X[m] * np.conj(xref) * osc) * win)
            phase_mk[m, k] = float(np.angle(cm))

    # normalize strength 0..1
    mx = float(np.max(strength_k)) + 1e-30
    strength_k = strength_k / mx
    return phase_mk, strength_k.astype(np.float64)


def _fit_delay_from_phase_slope(
    phase_wrapped: np.ndarray,   # (K,) radians
    freq_hz: np.ndarray,         # (K,) Hz absolute RF (fc_eff + tones)
    w: np.ndarray,               # (K,) weights 0..1
) -> float:
    """
    Fit tau from phase vs frequency:
      phi(f) ≈ -2π f tau + b
    We unwrap phase across frequency axis and do weighted least squares on slope.
    Returns tau (seconds).
    """
    K = int(phase_wrapped.size)
    if K < 3:
        return 0.0

    # unwrap across frequency dimension
    phi = np.unwrap(np.asarray(phase_wrapped, dtype=np.float64))

    f = np.asarray(freq_hz, dtype=np.float64)
    ww = np.asarray(w, dtype=np.float64)
    ww = np.clip(ww, 0.0, 1.0)
    if float(np.sum(ww)) <= 1e-12:
        ww[:] = 1.0

    # weighted linear regression phi = a*f + b, where a = dphi/df = -2π tau
    W = ww
    f0 = float(np.sum(W * f) / (np.sum(W) + 1e-30))
    y0 = float(np.sum(W * phi) / (np.sum(W) + 1e-30))

    df = (f - f0)
    dy = (phi - y0)

    num = float(np.sum(W * df * dy))
    den = float(np.sum(W * df * df)) + 1e-30
    a = num / den
    tau = -a / (2.0 * np.pi)
    return float(tau)


def _uca_positions(M: int, radius_m: float) -> np.ndarray:
    """
    UCA element positions in xy-plane for steering/delay prediction.
    element angles: 2π m / M (m=0..M-1)
    returns: (M,2) [x,y]
    """
    m = np.arange(M, dtype=np.float64)
    ang = 2.0 * np.pi * m / float(M)
    x = float(radius_m) * np.cos(ang)
    y = float(radius_m) * np.sin(ang)
    return np.stack([x, y], axis=1)


def circ_mean_from_prob(theta_deg: np.ndarray, p: np.ndarray) -> float:
    tg = np.asarray(theta_deg, dtype=np.float64).ravel()
    pp = np.asarray(p, dtype=np.float64).ravel()
    if tg.size < 4 or pp.size != tg.size:
        return 0.0
    s = float(np.sum(pp)) + 1e-30
    pp = pp / s
    ang = np.deg2rad(tg)
    C = float(np.sum(pp * np.cos(ang)))
    S = float(np.sum(pp * np.sin(ang)))
    return float((np.rad2deg(np.arctan2(S, C))) % 360.0)


def doa_mf_ps_tdoa_prob_uca(
    X_use: np.ndarray,           # (M,L) already UCA-ordered
    fs_hz: float,
    fc_eff_hz: float,            # absolute RF of “center tone” (fc + offset)
    radius_m: float,
    theta_grid_deg: np.ndarray,
    *,
    ref_ch: int = 0,
    k_tones: int = 5,
    tone_span_hz: float = 16000.0,     # span around 0 (baseband) used for multi-tone sampling
    beta: float = 12.0,
    sigma_tau_ns: float = 1.5,         # likelihood width (ns) 1..5 ns
    power_gamma: float = 1.0,
    coh_weights: Optional[np.ndarray] = None,   # optional per-channel coherence weights 0..1
) -> Tuple[Optional[float], float, np.ndarray, np.ndarray]:
    """
    Best-fit for your need:
    - Estimate per-channel relative delay via phase-slope across multiple tones (within band)
    - Then compute probability over theta using Gaussian likelihood in delay domain
    Returns: doa_deg, conf(0..1), theta_grid_deg, p_theta(sum=1)
    """
    tg = np.asarray(theta_grid_deg, dtype=np.float32).ravel()
    if X_use is None or not isinstance(X_use, np.ndarray) or X_use.ndim != 2:
        return None, 0.0, tg, np.zeros_like(tg, dtype=np.float32)

    M, L = X_use.shape
    if M < 2 or L < 64 or tg.size < 16:
        return None, 0.0, tg, np.zeros_like(tg, dtype=np.float32)

    ref_ch = int(max(0, min(M - 1, ref_ch)))

    # ----- choose tone offsets within [-span/2 .. +span/2] around 0Hz (baseband after your main mix) -----
    K = int(max(3, min(9, k_tones)))
    span = float(max(2000.0, tone_span_hz))
    offs = np.linspace(-0.5 * span, 0.5 * span, K, dtype=np.float64)

    # Estimate cross-phase per tone
    phase_mk, tone_strength = _extract_cross_phase_per_tone(
        X_use, float(fs_hz), offs.tolist(), ref_ch=ref_ch
    )

    # ----- channel power weight (stronger channel => higher weight) -----
    # use RMS power in this snapshot
    pwr = np.sqrt(np.mean(np.abs(X_use) ** 2, axis=1)).astype(np.float64)
    pwr = pwr / (float(np.max(pwr)) + 1e-30)
    wp = np.clip(pwr, 0.0, 1.0) ** float(max(0.0, power_gamma))

    # ----- coherence optional weight per channel -----
    if coh_weights is None:
        wc = np.ones((M,), dtype=np.float64)
    else:
        wc = np.asarray(coh_weights, dtype=np.float64).ravel()
        if wc.size != M:
            wc = np.ones((M,), dtype=np.float64)
        wc = np.clip(wc, 0.0, 1.0)

    wch = (wp * wc).astype(np.float64)
    # keep ref alive
    wch[ref_ch] = max(float(wch[ref_ch]), 0.25)
    wch = wch / (float(np.sum(wch)) + 1e-30)

    # ----- fit delay per channel from phase slope across frequencies -----
    # absolute RF for each tone = fc_eff + offs
    f_abs = (float(fc_eff_hz) + offs).astype(np.float64)
    # use tone weights (strong tones count more)
    wtone = np.clip(tone_strength, 0.0, 1.0).astype(np.float64)
    # avoid all-zero
    if float(np.sum(wtone)) <= 1e-12:
        wtone[:] = 1.0

    tau = np.zeros((M,), dtype=np.float64)
    for m in range(M):
        # relative to ref already inside phase_mk via x_m * conj(x_ref)
        tau[m] = _fit_delay_from_phase_slope(phase_mk[m, :], f_abs, wtone)

    # make relative delay with ref=0
    tau = tau - float(tau[ref_ch])

    # ----- probability over theta (delay-domain likelihood) -----
    # predicted tau_m(theta) from geometry:
    # tau_m = ( (p_m - p_ref) · u(theta) ) / c
    pos = _uca_positions(M, float(radius_m))  # (M,2)
    pref = pos[ref_ch]
    dpos = pos - pref  # (M,2)

    sigma = float(sigma_tau_ns) * 1e-9
    if sigma < 0.2e-9:
        sigma = 0.2e-9

    scores = np.zeros((tg.size,), dtype=np.float64)
    for i, th in enumerate(tg):
        th_rad = float(np.deg2rad(th))
        u = np.array([math.cos(th_rad), math.sin(th_rad)], dtype=np.float64)  # propagation direction

        tau_pred = (dpos @ u) / float(C_MPS)  # (M,)

        # weighted squared error
        err = tau - tau_pred
        # Gaussian likelihood (log-like up to constant)
        v = -0.5 * float(np.sum(wch * (err * err)) / (sigma * sigma))
        scores[i] = v

    # scores are log-likelihood-ish (negative), softmax them
    p_theta = _softmax_stable(scores, beta=float(beta))

    k = int(np.argmax(p_theta))

    # ✅ DOA from circular mean on probability (fixed)
    doa_deg = circ_mean_from_prob(tg, p_theta)

    # confidence from peak prominence (stable)
    eps = 1e-30
    H = -float(np.sum(p_theta * np.log(p_theta + eps)))
    Hmax = math.log(float(p_theta.size) + eps)
    conf = float(1.0 - (H / (Hmax + eps)))
    conf = max(0.0, min(1.0, conf))


    return doa_deg, conf, tg, p_theta


def doa_phase_first_strong_prob_uca(
    Xnb_use: np.ndarray,
    fc_eff_hz: float,
    radius_m: float,
    theta_grid_deg: np.ndarray,
    *,
    ref_ch: int = 0,
    beta: float = 14.0,
    coh_weights: Optional[np.ndarray] = None,
    power_gamma: float = 1.0,
    coh_gamma: float = 2.0,
    drop_coh_below: float = 0.55,
) -> Tuple[Optional[float], float, np.ndarray, np.ndarray]:
    """
    Narrowband-tone DOA probability (phase-based) with "first-strong" weighting.
    Returns:
      doa_deg, conf(0..1), theta_grid_deg, p_theta(probability sum=1)

    - Uses unit phasor per channel (phase only)
    - Weights channels by power^power_gamma and coherence^coh_gamma
    - ref_ch fixed (your request: 0)
    """
    tg = np.asarray(theta_grid_deg, dtype=np.float32).ravel()
    if Xnb_use is None or not isinstance(Xnb_use, np.ndarray) or Xnb_use.ndim != 2:
        return None, 0.0, tg, np.zeros_like(tg, dtype=np.float32)

    M, L = Xnb_use.shape
    if M < 2 or L < 16 or tg.size < 16:
        return None, 0.0, tg, np.zeros_like(tg, dtype=np.float32)

    ref_ch = int(max(0, min(M - 1, ref_ch)))

    # ----- 1) coherent integration -> phasor per channel -----
    w = np.hanning(L).astype(np.float32)
    w = w / (float(np.sum(w)) + 1e-30)
    y = np.sum(Xnb_use * w.reshape(1, L), axis=1)  # (M,)

    # unit phasor (phase only)
    mag = np.abs(y) + 1e-12
    z = (y / mag).astype(np.complex64)  # (M,)

    # ----- 2) power weight (stronger channel => higher weight) -----
    pwr = (mag / (float(np.max(mag)) + 1e-30)).astype(np.float32)  # 0..1
    wp = np.clip(pwr, 0.0, 1.0) ** float(max(0.0, power_gamma))

    # ----- 3) coherence weight (optional, from phase_debug) -----
    if coh_weights is None:
        wc = np.ones((M,), dtype=np.float32)
    else:
        wc = np.asarray(coh_weights, dtype=np.float32).ravel()
        if wc.size != M:
            wc = np.ones((M,), dtype=np.float32)
        wc = np.clip(wc, 0.0, 1.0)
        # drop noisy channels hard
        wc = np.where(wc < float(drop_coh_below), 0.0, wc)
        wc = wc ** float(max(0.0, coh_gamma))

    # ----- 4) combine weights, force ref_ch to be valid -----
    ww = (wp * wc).astype(np.float32)
    if float(np.sum(ww)) <= 1e-12:
        ww = np.ones((M,), dtype=np.float32)

    # always keep ref alive
    ww[ref_ch] = max(float(ww[ref_ch]), 0.25)
    ww = ww / (float(np.sum(ww)) + 1e-30)

    # ----- 5) scan theta -> phase match score(theta) -----
    # score(theta)=|Σ ww[m] * z[m] * conj(a_m(theta))|
    scores = np.zeros((tg.size,), dtype=np.float64)
    for i, th in enumerate(tg):
        a = uca_steering_vec(float(th), int(M), float(radius_m), float(fc_eff_hz))  # (M,)
        r = np.sum(ww * (z * np.conj(a)))
        scores[i] = float(np.abs(r))  # 0..1

    # ----- 6) probability spectrum -----
    p_theta = _softmax_stable(scores, beta=float(beta))

    # ----- 7) DOA + CONF (peak prominence) -----
    k = int(np.argmax(p_theta))
    doa_deg = float(tg[k])

    N = float(p_theta.size)
    pmax = float(p_theta[k])
    ratio = max(0.0, (pmax * N) - 1.0)     # 0=flat, higher=sharper peak
    conf = float(1.0 - np.exp(-0.35 * ratio))
    conf = max(0.0, min(1.0, conf))

    return doa_deg, conf, tg, p_theta


def doa_prob_phase_uca_from_snapshot(
    Xnb_use: np.ndarray,
    fc_eff_hz: float,
    radius_m: float,
    theta_grid_deg: np.ndarray,
    *,
    beta: float = 10.0,
    coh_weights: Optional[np.ndarray] = None,
) -> Tuple[Optional[float], float, np.ndarray, np.ndarray]:
    """
    Phase-likelihood DOA for narrowband tone on UCA.
    Returns:
      doa_deg(or None), conf(0..1), theta_grid_deg, p_theta(probability, sum=1)

    - Xnb_use: (M,L) after mix+FIR
    - coh_weights: optional per-channel weights (0..1), length M
    """
    if Xnb_use is None or not isinstance(Xnb_use, np.ndarray) or Xnb_use.ndim != 2:
        tg = np.asarray(theta_grid_deg, dtype=np.float32)
        return None, 0.0, tg, np.zeros_like(tg, dtype=np.float32)

    M, L = Xnb_use.shape
    tg = np.asarray(theta_grid_deg, dtype=np.float32).ravel()
    if M < 2 or L < 8 or tg.size < 8:
        return None, 0.0, tg, np.zeros_like(tg, dtype=np.float32)

    # 1) coherent integration (Hann window) -> phasor per channel
    w = np.hanning(L).astype(np.float32)
    w = w / (float(np.sum(w)) + 1e-30)
    y = np.sum(Xnb_use * w.reshape(1, L), axis=1)  # (M,)

    # 2) normalize to unit phasor (remove amp)
    mag = np.abs(y) + 1e-12
    z = (y / mag).astype(np.complex64)  # unit phasor per channel

    # 3) optional weights (e.g., coherence)
    if coh_weights is None:
        ww = np.ones((M,), dtype=np.float32)
    else:
        ww = np.asarray(coh_weights, dtype=np.float32).ravel()
        if ww.size != M:
            ww = np.ones((M,), dtype=np.float32)
        ww = np.clip(ww, 0.0, 1.0)
        # emphasize good channels a bit
        ww = ww ** 2.0

    # normalize weights
    ww = ww / (float(np.sum(ww)) + 1e-30)

    # 4) scan theta -> score(theta)
    scores = np.zeros((tg.size,), dtype=np.float64)
    for i, th in enumerate(tg):
        a = uca_steering_vec(float(th), int(M), float(radius_m), float(fc_eff_hz))  # (M,)
        r = np.sum(ww * (z * np.conj(a)))
        scores[i] = float(np.abs(r))  # 0..1

    # 5) probability spectrum
    p_theta = _softmax_stable(scores, beta=float(beta))  # sum=1

    # 6) DOA + confidence
    k = int(np.argmax(p_theta))
    doa_deg = float(tg[k])

    # confidence from entropy (0..1): 1 = very sharp, 0 = flat
    eps = 1e-30
    H = -float(np.sum(p_theta * np.log(p_theta + eps)))
    Hmax = math.log(float(p_theta.size) + eps)
    conf = float(1.0 - (H / (Hmax + eps)))
    conf = max(0.0, min(1.0, conf))

    return doa_deg, conf, tg, p_theta


from typing import Optional, Tuple, Dict, Any
import numpy as np

C0 = 299_792_458.0  # speed of light


def _uca_steering_mat(theta_deg: np.ndarray, M: int, radius_m: float, fc_hz: float) -> np.ndarray:
    """
    UCA steering matrix A: shape (M, K), K=len(theta_deg)
    Model: phase = exp(-j * k * r * cos(theta - phi_m))
    where phi_m are antenna angular positions around the circle.
    """
    theta = np.deg2rad(theta_deg.astype(np.float64))  # (K,)
    phi_m = 2.0 * np.pi * (np.arange(M, dtype=np.float64) / float(M))  # (M,)
    k = 2.0 * np.pi * (float(fc_hz) / C0)  # rad/m

    # (M,K): cos(theta - phi_m)
    cos_term = np.cos(theta[None, :] - phi_m[:, None])
    phase = -1j * k * float(radius_m) * cos_term
    A = np.exp(phase).astype(np.complex128)

    # normalize steering vectors to unit norm (helps scale invariance)
    A /= (np.linalg.norm(A, axis=0, keepdims=True) + 1e-12)
    return A


def circ_mean_from_prob(theta_deg: np.ndarray, p: np.ndarray) -> Optional[float]:
    """Circular mean on degrees using probability p (sum=1)."""
    if p is None or p.size == 0:
        return None
    p = np.asarray(p, dtype=np.float64).ravel()
    s = float(np.sum(p))
    if not np.isfinite(s) or s <= 0:
        return None
    p = p / s

    ang = np.deg2rad(np.asarray(theta_deg, dtype=np.float64).ravel())
    c = float(np.sum(p * np.cos(ang)))
    s = float(np.sum(p * np.sin(ang)))
    if not np.isfinite(c) or not np.isfinite(s):
        return None

    mu = np.rad2deg(np.arctan2(s, c))
    mu = (mu + 360.0) % 360.0
    return float(mu)


def doa_phasefit_uca_from_snapshot(
    Xnb_use: np.ndarray,
    fc_eff_hz: float,
    radius_m: float,
    theta_grid_deg: np.ndarray,
    *,
    # ---- knobs you can tune ----
    dc_remove: bool = True,            # ลด bias/DC ที่ทำให้เฟสปั่น
    power_norm: bool = True,           # normalize ต่อเสา ลด amplitude imbalance
    diag_load: float = 1e-2,           # diagonal loading (0.001..0.05)
    use_phase_only: bool = False,      # True = ใช้ phase-only (PHAT-ish) ลดผลจาก AGC
    peak_excl_deg: float = 8.0,        # ช่วงกัน argmax บริเวณ peak ตอนหา 2nd peak
    # --------------------------------
) -> Tuple[Optional[float], float, np.ndarray]:
    """
    Better UCA DOA using Bartlett scan on covariance:
      P(theta) = a^H R a

    Returns:
      doa_deg (circular mean from prob) or None,
      conf (peak-prominence based),
      p_theta (probability over theta_grid, sum=1)
    """
    # --------- validate ---------
    if Xnb_use is None or not isinstance(Xnb_use, np.ndarray) or Xnb_use.ndim != 2:
        z = np.zeros_like(theta_grid_deg, dtype=np.float32)
        return None, 0.0, z

    M, L = Xnb_use.shape
    if M < 2 or L < 16 or theta_grid_deg is None or len(theta_grid_deg) < 8:
        z = np.zeros_like(theta_grid_deg, dtype=np.float32)
        return None, 0.0, z

    X = Xnb_use.astype(np.complex128, copy=False)

    # --------- preprocess ---------
    if dc_remove:
        # remove per-antenna mean (DC) across time
        X = X - np.mean(X, axis=1, keepdims=True)

    if use_phase_only:
        # keep only phase per sample (avoid amplitude issues)
        X = X / (np.abs(X) + 1e-12)

    if power_norm:
        # normalize per-antenna RMS power to reduce imbalance
        pwr = np.mean((X.real * X.real + X.imag * X.imag), axis=1, keepdims=True)
        X = X / (np.sqrt(pwr) + 1e-12)

    # --------- covariance ---------
    # R = X X^H / L
    R = (X @ X.conj().T) / float(L)

    # diagonal loading (stabilize + reduce spurious sharp peaks)
    tr = float(np.real(np.trace(R)))
    if not np.isfinite(tr) or tr <= 0:
        z = np.zeros_like(theta_grid_deg, dtype=np.float32)
        return None, 0.0, z

    eps = float(diag_load) * (tr / float(M))
    R = R + (eps * np.eye(M, dtype=np.complex128))

    # --------- Bartlett scan (vectorized) ---------
    A = _uca_steering_mat(np.asarray(theta_grid_deg), int(M), float(radius_m), float(fc_eff_hz))  # (M,K)
    RA = R @ A  # (M,K)
    # Pk = a^H R a = sum(conj(a) * (R a))
    P = np.real(np.sum(np.conj(A) * RA, axis=0)).astype(np.float64)  # (K,)
    P = np.maximum(P, 0.0)

    Psum = float(np.sum(P))
    if not np.isfinite(Psum) or Psum <= 0:
        z = np.zeros_like(theta_grid_deg, dtype=np.float32)
        return None, 0.0, z

    # Probability-like normalize (sum=1)
    p_theta = (P / (Psum + 1e-30)).astype(np.float32)

    # DOA from circular mean on prob (นิ่งกว่า argmax)
    doa_deg = circ_mean_from_prob(theta_grid_deg, p_theta)

    # --------- confidence (peak prominence + peak-vs-2nd-peak) ---------
    k0 = int(np.argmax(p_theta))
    p0 = float(p_theta[k0])

    # find 2nd peak excluding neighborhood around main peak
    th = np.asarray(theta_grid_deg, dtype=np.float64)
    d = np.abs(((th - float(th[k0]) + 180.0) % 360.0) - 180.0)  # circular distance in deg
    mask = d > float(peak_excl_deg)
    p2 = float(np.max(p_theta[mask])) if np.any(mask) else 0.0

    meanp = float(np.mean(p_theta))
    # conf combines: how much higher than average + how dominant vs 2nd peak
    conf_prom = p0 / (meanp + 1e-9)
    conf_psr = p0 / (p2 + 1e-9)
    conf = float(0.6 * conf_prom + 0.4 * conf_psr)

    return doa_deg, conf, p_theta



def music_1d_uca(X: np.ndarray,
                 fc_hz: float,
                 radius_m: float,
                 num_sources: int,
                 theta_min_deg: float,
                 theta_max_deg: float,
                 theta_step_deg: float):
    M, L = X.shape
    if num_sources >= M:
        num_sources = M - 1
    if num_sources < 1:
        num_sources = 1

    # -----------------------------
    # Robust preprocessing
    # -----------------------------
    Xc = X - np.mean(X, axis=1, keepdims=True)

    rms = np.sqrt(np.mean(np.abs(Xc) ** 2, axis=1, keepdims=True)) + 1e-12
    Xn = Xc / rms

    R = (Xn @ Xn.conj().T) / float(L)
    R = (R + R.conj().T) * 0.5

    tr = float(np.real(np.trace(R)))
    if tr > 0:
        dl = 1e-3 * (tr / M)
        R = R + (dl * np.eye(M, dtype=R.dtype))

    eigvals, eigvecs = np.linalg.eigh(R)
    idx = np.argsort(eigvals)
    V = eigvecs[:, idx]
    Un = V[:, :M - num_sources]

    m_idx = np.arange(M)
    elem_phi = 2.0 * np.pi * m_idx / M

    k = 2.0 * np.pi * float(fc_hz) / C_MPS

    theta_grid_deg = np.arange(theta_min_deg, theta_max_deg, theta_step_deg, dtype=np.float32)
    theta_rad = np.deg2rad(theta_grid_deg)

    P = np.zeros_like(theta_rad, dtype=np.float64)

    for i, th in enumerate(theta_rad):
        phase = -1j * k * float(radius_m) * np.cos(th - elem_phi)
        a = np.exp(phase).reshape(M, 1)
        UnH_a = Un.conj().T @ a
        denom = np.vdot(UnH_a, UnH_a).real
        if denom < 1e-12:
            denom = 1e-12
        P[i] = 1.0 / denom

    P_max = float(P.max())
    P_norm = (P / P_max) if (P_max > 0) else np.zeros_like(P)
    peak_idx = int(P.argmax())
    doa_deg = float(theta_grid_deg[peak_idx])

    conf = float(P_norm[peak_idx] / (P_norm.mean() + 1e-9))

    return doa_deg, conf, theta_grid_deg, P_norm.astype(np.float32)


# ================== FFT SPECTRUM ==================

def compute_rf_fft(X: np.ndarray, fs_hz: float, fc_hz: float,
                   fft_points: int, fft_downsample: int, ch_index: int):
    M, _ = X.shape
    ch_index = int(ch_index)
    if ch_index < 0 or ch_index >= M:
        ch_index = 0

    ch = X[ch_index]
    L = ch.size
    if L < 16:
        raise ValueError("Not enough samples for FFT")

    max_pow2 = 1 << int(np.floor(np.log2(L)))
    nfft = int(min(int(fft_points), max_pow2))
    if nfft < 16:
        nfft = 16

    seg = ch[:nfft]
    win = np.hanning(nfft).astype(np.float32)
    cg = float(np.sum(win)) / float(nfft)
    segw = seg * win
    spec = np.fft.fftshift(np.fft.fft(segw))
    spec_amp = spec / (float(nfft) * cg + 1e-30)

    p_bin = (np.abs(spec_amp) ** 2).astype(np.float64)
    p_dbfs = 10.0 * np.log10(p_bin + 1e-30)

    freqs = np.fft.fftshift(np.fft.fftfreq(nfft, d=1.0 / fs_hz))
    freq_abs = float(fc_hz) + freqs

    ds = max(1, int(fft_downsample))
    return freq_abs[::ds].astype(np.float32), p_dbfs[::ds].astype(np.float32), ch_index


def compute_band_peak_db(fft_freq_hz, fft_mag_db, fc_hz, offset_hz, bw_hz) -> float:
    f0 = float(fc_hz) + float(offset_hz)
    half = float(bw_hz) * 0.5
    f = np.asarray(fft_freq_hz, dtype=np.float64)
    m = np.asarray(fft_mag_db, dtype=np.float64)
    idx = np.where((f >= (f0 - half)) & (f <= (f0 + half)))[0]
    if idx.size == 0:
        return -200.0
    return float(np.max(m[idx]))


def compute_band_peak_db_per_channel(X: np.ndarray,
                                     fs_hz: float,
                                     fc_hz: float,
                                     fft_points: int,
                                     fft_downsample: int,
                                     offset_hz: float,
                                     bw_hz: float) -> List[float]:
    peaks = []
    M, _ = X.shape
    for ch in range(M):
        f_tmp, mdb_tmp, _ = compute_rf_fft(
            X, fs_hz, fc_hz,
            int(fft_points), int(fft_downsample),
            int(ch)
        )
        peaks.append(float(compute_band_peak_db(f_tmp, mdb_tmp, fc_hz, offset_hz, bw_hz)))
    return peaks


# ================== CLAMPS ==================

def _clamp_tx_hz(hz: float) -> float:
    hz = float(hz)
    if hz < MIN_TX_HZ:
        hz = MIN_TX_HZ
    if hz > MAX_TX_HZ:
        hz = MAX_TX_HZ
    return hz


def _clamp_rf_hz(hz: float) -> int:
    hz = int(hz)
    if hz < MIN_RF_HZ:
        hz = MIN_RF_HZ
    if hz > MAX_RF_HZ:
        hz = MAX_RF_HZ
    return hz


# ================== RF Band WS (optional) ==================

def _rf_band_ws_send_set_common(freq_hz: int, state: dict):
    try:
        freq_hz = int(freq_hz)
    except Exception:
        return False, "invalid freq"

    now = time.monotonic()
    last_hz = int(state.get("_last_band_apply_hz", -1))
    last_ts = float(state.get("_last_band_apply_ts", 0.0))

    if freq_hz == last_hz and (now - last_ts) < 2.0:
        return True, "skip(same freq)"
    if (now - last_ts) < RF_BAND_APPLY_COOLDOWN_SEC:
        return True, "skip(cooldown)"

    payload = {"cmd": "set_df_common", "freq_hz": freq_hz, "client": "df"}
    try:
        import asyncio
        import websockets

        async def _send():
            uri = f"ws://{RF_BAND_WS_HOST}:{RF_BAND_WS_PORT}"
            async with websockets.connect(uri, open_timeout=0.5, close_timeout=0.5) as ws:
                await ws.send(json.dumps(payload))

        asyncio.run(_send())
        state["_last_band_apply_hz"] = int(freq_hz)
        state["_last_band_apply_ts"] = now
        return True, "ok"
    except Exception as e:
        return False, str(e)


# ================== MTS + NCO APPLY (core) ==================

def _apply_setfreq_mts_then_nco(freq_hz: int, upd_mask: int, state: dict) -> Dict[str, Any]:
    """
    เรียก rfsoc_adc_mts (ชุดใหม่) ให้ทำ:
      1) MTS/SYSREF จัด phase/latency ของ tiles
      2) หน่วง post_mts_delay_ms
      3) apply NCO (freq/en/phase/rst)
    """
    freq_hz = int(freq_hz)
    upd_mask = int(upd_mask) & 0x3F

    rf_mts_bin = str(state.get("rf_mts_bin", DEFAULT_RF_MTS_BIN))
    tiles = str(state.get("mts_tiles", DEFAULT_MTS_TILES))
    gpiochip = str(state.get("mts_gpiochip", DEFAULT_GPIOCHIP))
    lmk_reset = str(state.get("mts_lmk_reset", DEFAULT_LMK_RESET))
    lmk_sync = str(state.get("mts_lmk_sync", DEFAULT_LMK_SYNC))
    spidev = str(state.get("mts_spidev", DEFAULT_SPI_DEV))
    do_lmk_init = str(state.get("mts_do_lmk_init", DEFAULT_DO_LMK_INIT))
    sysref_shots = str(state.get("mts_sysref_shots", DEFAULT_SYSREF_SHOTS))
    sysref_pulse = str(state.get("mts_sysref_pulse", DEFAULT_SYSREF_PULSE))
    sysref_repeat = str(state.get("mts_sysref_repeat", DEFAULT_SYSREF_REPEAT))
    sysref_delay_us = str(state.get("mts_sysref_delay_us", DEFAULT_SYSREF_DELAY_US))

    init_once = str(int(state.get("mts_init_once", 1)))
    setfreq = str(int(state.get("mts_setfreq", 1)))

    nco_base = str(state.get("nco_base", DEFAULT_NCO_BASE_STR))
    fs_hz = str(state.get("nco_fs_hz", DEFAULT_NCO_FS_STR))
    phase = str(int(state.get("nco_phase", DEFAULT_NCO_PHASE)))
    rst = str(int(state.get("nco_rst", DEFAULT_NCO_RST)))

    post_delay_ms = str(int(state.get("post_mts_delay_ms", DEFAULT_POST_MTS_DELAY_MS)))

    cmd = [
        rf_mts_bin,
        "--setfreq", setfreq,
        "--init_once", init_once,
        "--tiles", tiles,
        "--gpiochip", gpiochip,
        "--lmk_reset", lmk_reset,
        "--lmk_sync", lmk_sync,
        "--spidev", spidev,
        "--do_lmk_init", do_lmk_init,
        "--sysref_shots", sysref_shots,
        "--sysref_pulse", sysref_pulse,
        "--sysref_repeat", sysref_repeat,
        "--sysref_delay_us", sysref_delay_us,
        "--nco_base", nco_base,
        "--fs", fs_hz,
        "--freq", str(freq_hz),
        "--en", hex(upd_mask),
        "--phase", phase,
        "--rst", rst,
        "--post_mts_delay_ms", post_delay_ms,
    ]

    t0 = time.time()
    p = subprocess.run(cmd, capture_output=True, text=True)
    dt_ms = int((time.time() - t0) * 1000)

    info = {
        "cmd": cmd,
        "returncode": int(p.returncode),
        "elapsed_ms": dt_ms,
        "stdout": (p.stdout or "").strip(),
        "stderr": (p.stderr or "").strip(),
        "ok": (p.returncode == 0),
        "freq_hz": int(freq_hz),
        "en": int(upd_mask),
        "post_mts_delay_ms": int(post_delay_ms),
    }

    if p.returncode != 0:
        raise RuntimeError(
            f"rfsoc_adc_mts --setfreq failed rc={p.returncode} "
            f"stderr={info['stderr'][:400]}"
        )

    return info


# ================== ACK / STATE ==================

def _send_ack(conn: socket.socket, ack_for: str, state: Dict[str, Any], extra: Optional[Dict[str, Any]] = None):
    payload = {
        "menuID": "Ack",
        "timestamp": datetime.now().isoformat(),
        "ackFor": ack_for,
        "state": {
            "stream_enabled": bool(state["stream_enabled"]),
            "doa_enabled": bool(state["doa_enabled"]),
            "spectrum_enabled": bool(state["spectrum_enabled"]),
            "fft_points": int(state["fft_points"]),
            "fft_downsample": int(state["fft_downsample"]),
            "fft_channel": int(state["fft_channel"]),
            "tx_hz": float(state["tx_hz"]),
            "fc_hz": float(state["fc_hz"]),
            "doa_offset_hz": float(state["doa_offset_hz"]),
            "doa_bw_hz": float(state["doa_bw_hz"]),
            "doa_algo": str(state.get("doa_algo", DEFAULT_DOA_ALGO)),
            "gate_th_db": float(state["gate_th_db"]),
            "rf_agc_enabled": bool(state.get("rf_agc_enabled", False)),
            "rf_agc_ch_enabled": list(state.get("rf_agc_ch_enabled", [])),
            "rf_agc_target_db": list(state.get("rf_agc_target_db", [])),
            "scanner_att_db": float(state.get("scanner_att_db", DEFAULT_SCANNER_ATT_DB)),
            "uca_radius_m": float(state.get("uca_radius_m", UCA_RADIUS_M)),
            "num_antennas": int(state.get("num_antennas", NUM_CH)),
            "nco_update_en": int(state["nco_update_en"]),
            "rf_range_hz": [MIN_RF_HZ, MAX_RF_HZ],

            "phase_debug_enable": bool(state.get("phase_debug_enable", True)),
            "phase_debug_interval_ms": int(state.get("phase_debug_interval_ms", 1000)),
            "phase_debug_ref_ch": int(state.get("phase_debug_ref_ch", 0)),

            "post_mts_delay_ms": int(state.get("post_mts_delay_ms", DEFAULT_POST_MTS_DELAY_MS)),
        }
    }
    if extra:
        payload.update(extra)
    _send_control(conn, json.dumps(payload) + "\n")


# ================== Link event (ConnMan monitor) ==================

def _send_link_event(conn: socket.socket, ifname: str, up: bool):
    payload = {
        "menuID": "LinkState",
        "timestamp": datetime.now().isoformat(),
        "ifname": str(ifname),
        "link_up": bool(up),
    }
    _send_control(conn, json.dumps(payload) + "\n")


# ================== COMMAND RX ==================

def _try_recv_commands(conn: socket.socket, rxbuf: bytearray, state: Dict[str, Any], nco_unused):
    global _G_AGC_PER_CH, _G_ATT_MAP

    r, _, _ = select.select([conn], [], [], 0.0)
    if not r:
        return

    try:
        data = conn.recv(4096)
    except (BlockingIOError, InterruptedError):
        return

    if not data:
        raise ConnectionResetError("Client closed")

    rxbuf.extend(data)

    while True:
        nl = rxbuf.find(b"\n")
        if nl < 0:
            break
        line = rxbuf[:nl].strip()
        del rxbuf[:nl + 1]

        if not line:
            continue

        try:
            msg = json.loads(line.decode("utf-8", errors="replace"))
        except Exception:
            continue

        menu = msg.get("menuID", "")
        need_ack = bool(msg.get("needAck", False))

        if menu == "setSpectrumEnable":
            state["spectrum_enabled"] = bool(msg.get("enable", True))
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setDoaEnable":
            state["doa_enabled"] = bool(msg.get("enable", True))
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setStreamEnable":
            state["stream_enabled"] = bool(msg.get("enable", True))
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setFftConfig":
            fp = msg.get("fft_points", state["fft_points"])
            ds = msg.get("fft_downsample", state["fft_downsample"])
            try:
                state["fft_points"] = int(fp)
                state["fft_downsample"] = int(ds)
            except Exception:
                pass
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setAdcChannel":
            ch = msg.get("channel", state["fft_channel"])
            try:
                ch = int(ch)
            except Exception:
                ch = int(state["fft_channel"])
            ch = max(0, min(NUM_CH - 1, ch))
            state["fft_channel"] = ch
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu in ("setIqSwap", "setIQSwap", "setIqSwapEnable", "setIQSwapEnable"):
            en = msg.get("enable", msg.get("swap", state.get("iq_swap", DEFAULT_IQ_SWAP)))
            state["iq_swap"] = bool(en)
            if need_ack:
                _send_ack(conn, "setIqSwap", state)

        elif menu == "setTxHz":
            hz = msg.get("hz", state["tx_hz"])
            try:
                hz = float(hz)
            except Exception:
                hz = float(state["tx_hz"])
            state["tx_hz"] = _clamp_tx_hz(hz)
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setTxIntervalMs":
            ms = msg.get("ms", None)
            try:
                ms = float(ms)
            except Exception:
                ms = None
            if ms is None:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"error": "invalid ms"})
                continue
            ms = max(16.0, min(5000.0, ms))
            state["tx_hz"] = _clamp_tx_hz(1000.0 / ms)
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setDoaTargetOffsetHz":
            off = msg.get("offset_hz", state["doa_offset_hz"])
            try:
                off = float(off)
            except Exception:
                off = float(state["doa_offset_hz"])
            nyq = 0.49 * FS
            off = max(-nyq, min(nyq, off))
            state["doa_offset_hz"] = off
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setDoaBwHz":
            bw = msg.get("bw_hz", state["doa_bw_hz"])
            try:
                bw = float(bw)
            except Exception:
                bw = float(state["doa_bw_hz"])
            bw = max(50.0, min(0.45 * FS, bw))
            state["doa_bw_hz"] = bw
            state["_fir_cache"] = None
            state["_fir_cutoff_cache"] = -1.0
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setDoaAlgorithm":
            algo = str(msg.get("algo", state.get("doa_algo", DEFAULT_DOA_ALGO))).strip().lower()
            if algo in ("music", "rb_music", "uca_rb_music", "uca-rb-music"):
                state["doa_algo"] = "uca_rb_music"
            elif algo in ("esprit", "uca_esprit", "uca-esprit"):
                state["doa_algo"] = "uca_esprit"
            elif algo in ("music_1d", "music_1d_uca", "internal_music"):
                state["doa_algo"] = "music_1d_uca"
            elif algo in ("phasefit_uca", "phasefit", "bartlett", "beamform"):
                state["doa_algo"] = "phasefit_uca"
            elif algo in ("phase_prob_uca", "phase_prob", "prob_phase", "phase_likelihood"):
                state["doa_algo"] = "phase_prob_uca"
            elif algo in ("phase_first_strong_prob_uca", "phase_first_strong", "phase_prob_strong", "prob_strong"):
                state["doa_algo"] = "phase_first_strong_prob_uca"
            elif algo in ("mf_ps_tdoa_prob_uca", "mf_tdoa", "tdoa_prob", "mf_phase_tdoa"):
                state["doa_algo"] = "mf_ps_tdoa_prob_uca"
            else:
                print(f"[WARN] Unknown DOA algorithm: {algo} (keep {state.get('doa_algo')})")
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setDoaPowerThresholdDb":
            th = msg.get("th_db", state["gate_th_db"])
            try:
                th = float(th)
            except Exception:
                th = float(state["gate_th_db"])
            th = max(-200.0, min(50.0, th))
            state["gate_th_db"] = th
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setPhaseDebug":
            state["phase_debug_enable"] = bool(msg.get("enable", True))
            try:
                state["phase_debug_interval_ms"] = int(msg.get("interval_ms", state.get("phase_debug_interval_ms", 1000)))
            except Exception:
                pass
            try:
                state["phase_debug_ref_ch"] = int(msg.get("ref_ch", state.get("phase_debug_ref_ch", 0)))
            except Exception:
                pass
            if need_ack:
                _send_ack(conn, menu, state, extra={
                    "phase_debug_enable": bool(state["phase_debug_enable"]),
                    "phase_debug_interval_ms": int(state["phase_debug_interval_ms"]),
                    "phase_debug_ref_ch": int(state["phase_debug_ref_ch"]),
                })

        elif menu == "setScannerAttDb":
            adb = msg.get("att_db", msg.get("db", None))
            try:
                adb = float(adb)
            except Exception:
                adb = None

            if adb is None:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"error": "invalid att_db"})
                continue

            if adb < 0.0:
                adb = 0.0
            if adb > 31.75:
                adb = 31.75

            state["scanner_att_db"] = float(adb)

            if (_G_ATT_MAP is not None) and (SCANNER_ATT_INDEX in _G_ATT_MAP):
                try:
                    _G_ATT_MAP[SCANNER_ATT_INDEX].set_db(float(adb))
                except Exception as e:
                    if need_ack:
                        _send_ack(conn, menu, state, extra={"error": f"scanner_att_set_failed: {e}"})
                    continue
            else:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"error": "scanner_att_not_available"})
                continue

            if need_ack:
                _send_ack(conn, menu, state, extra={"scanner_att_db": float(adb)})

        elif menu == "setRfAgcEnable":
            ch = msg.get("ch", -1)
            en = bool(msg.get("enable", True))
            try:
                ch = int(ch)
            except Exception:
                ch = -1

            if ch < 0:
                state["rf_agc_enabled"] = bool(en and _ATT_AGC_OK)
                state["rf_agc_ch_enabled"] = [bool(state["rf_agc_enabled"])] * int(NUM_CH)

            if (not state.get("rf_agc_enabled", False)) and (_G_AGC_PER_CH is not None):
                try:
                    for i in range(min(int(NUM_CH), len(_G_AGC_PER_CH))):
                        _G_AGC_PER_CH[i].force(0.0)
                except Exception:
                    pass
            else:
                if 0 <= ch < int(NUM_CH):
                    state["rf_agc_ch_enabled"][ch] = bool(en and _ATT_AGC_OK)
                    if (not state["rf_agc_ch_enabled"][ch]) and (_G_AGC_PER_CH is not None) and (0 <= ch < len(_G_AGC_PER_CH)):
                        try:
                            _G_AGC_PER_CH[ch].force(0.0)
                        except Exception:
                            pass

            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setRfAgcChannel":
            ch = msg.get("ch", -1)
            target = msg.get("target_db", None)
            try:
                ch = int(ch)
            except Exception:
                ch = -1
            try:
                target = float(target)
            except Exception:
                target = None

            if (target is None) or (ch < 0) or (ch >= int(NUM_CH)):
                if need_ack:
                    _send_ack(conn, menu, state, extra={"error": "invalid ch/target_db"})
                continue

            for i in range(int(NUM_CH)):
                state["rf_agc_target_db"][i] = float(target)

            if _G_AGC_PER_CH is not None and 0 <= ch < len(_G_AGC_PER_CH):
                try:
                    for i in range(min(int(NUM_CH), len(_G_AGC_PER_CH))):
                        _G_AGC_PER_CH[i].set_target(float(target))
                except Exception:
                    pass

            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setUcaRadiusM":
            r = msg.get("radius_m", state.get("uca_radius_m", UCA_RADIUS_M))
            try:
                r = float(r)
            except Exception:
                r = float(state.get("uca_radius_m", UCA_RADIUS_M))
            r = max(0.01, min(1000.0, r))
            state["uca_radius_m"] = r
            state["_doa_py_uca"] = None
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setNumAntennas":
            n = msg.get("num", state.get("num_antennas", NUM_CH))
            try:
                n = int(n)
            except Exception:
                n = int(state.get("num_antennas", NUM_CH))
            n = max(2, min(NUM_CH, n))
            state["num_antennas"] = n
            state["_doa_py_uca"] = None
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setFcHz":
            fc = msg.get("fc_hz", state["fc_hz"])
            try:
                fc = float(fc)
            except Exception:
                fc = float(state["fc_hz"])
            fc_i = _clamp_rf_hz(fc)
            state["fc_hz"] = float(fc_i)
            ok_band, band_msg = _rf_band_ws_send_set_common(int(fc_i), state)
            if need_ack:
                _send_ack(conn, menu, state, extra={
                    "rf_range_hz": [MIN_RF_HZ, MAX_RF_HZ],
                    "band_apply_ok": bool(ok_band),
                    "band_apply_msg": str(band_msg),
                })

        elif menu == "setFrequencyHz":
            freq = msg.get("freq_hz", None)
            upd = msg.get("update_en", state.get("nco_update_en", DEFAULT_UPDATE_EN))
            try:
                freq = int(freq)
            except Exception:
                freq = None
            try:
                upd = int(upd) & 0x3F
            except Exception:
                upd = int(state.get("nco_update_en", DEFAULT_UPDATE_EN)) & 0x3F

            if freq is None:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"error": "freq_hz missing"})
                continue

            freq = _clamp_rf_hz(freq)
            state["nco_update_en"] = upd

            try:
                info = _apply_setfreq_mts_then_nco(freq, upd, state)
                ok_band, band_msg = _rf_band_ws_send_set_common(freq, state)
                state["fc_hz"] = float(freq)

                if need_ack:
                    _send_ack(conn, menu, state, extra={
                        "mts_nco": info,
                        "rf_range_hz": [MIN_RF_HZ, MAX_RF_HZ],
                        "band_apply_ok": bool(ok_band),
                        "band_apply_msg": str(band_msg),
                    })
            except Exception as e:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"error": f"setfreq_failed: {e}"})

        elif menu == "getState":
            if need_ack:
                _send_ack(conn, menu, state)

        elif menu == "setIpConfig":
            ifname = str(msg.get("ifname", "")).strip()
            ip = str(msg.get("ip", "")).strip()
            netmask = str(msg.get("netmask", "")).strip()

            gateway = msg.get("gateway", None)
            dns1 = msg.get("dns1", None)
            dns2 = msg.get("dns2", None)

            if not ifname or not ip or not netmask:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"ok": False, "error": "missing ifname/ip/netmask"})
                continue

            if not _CONNMAN_OK or ConnmanManager is None:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"ok": False, "error": "connman_driver_not_available"})
                continue

            dns_list = []
            if dns1:
                dns_list.append(str(dns1).strip())
            if dns2:
                dns_list.append(str(dns2).strip())

            try:
                cm = ConnmanManager("connmanctl")
                result = cm.config_ipv4_manual(
                    ifname=ifname,
                    ip=ip,
                    netmask=netmask,
                    gateway=(str(gateway).strip() if gateway else None),
                    dns=(dns_list if dns_list else None),
                )
                link = cm.link_state(ifname)

                new_ip = get_iface_ipv4_ioctl(ifname) or ip
                new_ip = str(new_ip).strip() if new_ip else TCP_HOST

                state["_tcp_bind_host"] = new_ip
                state["_tcp_restart_reason"] = f"ip_changed:{ifname}"
                state["_tcp_restart"] = True
                state["_disconnect_client"] = True

                if need_ack:
                    _send_ack(conn, menu, state, extra={
                        "ok": True,
                        "net": {
                            "ifname": ifname,
                            "service_id": result.get("service_id", ""),
                            "ip": ip,
                            "netmask": netmask,
                            "gateway": result.get("gateway", ""),
                            "dns": dns_list,
                        },
                        "link": link,
                        "tcp_restart": True,
                        "tcp_bind_host": new_ip,
                        "tcp_port": int(TCP_PORT),
                    })

            except ConnmanError as e:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"ok": False, "error": str(e)})

        elif menu == "getLinkState":
            ifname = str(msg.get("ifname", "")).strip()
            if not ifname:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"ok": False, "error": "missing ifname"})
                continue

            if not _CONNMAN_OK or ConnmanManager is None:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"ok": False, "error": "connman_driver_not_available"})
                continue

            try:
                cm = ConnmanManager("connmanctl")
                link = cm.link_state(ifname)
                if need_ack:
                    _send_ack(conn, menu, state, extra={"ok": True, "link": link})
            except ConnmanError as e:
                if need_ack:
                    _send_ack(conn, menu, state, extra={"ok": False, "error": str(e)})

        else:
            # unknown menuID -> optional ack
            if need_ack:
                _send_ack(conn, menu, state, extra={"error": f"unknown menuID: {menu}"})


# ================== DOA OUTPUT FIX ==================

def wrap_deg_360(x: float) -> float:
    x = float(x) % 360.0
    if x < 0:
        x += 360.0
    return x


def doa_add_180(doa_deg: float) -> float:
    # ✅ front/back flip compensation
    return wrap_deg_360(float(doa_deg) + 180.0)


def rotate_polar_spectrum(theta_grid_deg: np.ndarray,
                          P_norm: np.ndarray,
                          rotate_deg: float = 180.0):
    """
    Rotate polar spectrum by rotate_deg (default +180°).
    Assumes theta_grid_deg is uniform (constant step).
    Returns (theta_grid_deg_same, P_norm_rotated)
    """
    if theta_grid_deg is None or P_norm is None:
        return theta_grid_deg, P_norm

    tg = np.asarray(theta_grid_deg, dtype=np.float32).ravel()
    pn = np.asarray(P_norm, dtype=np.float32).ravel()

    if tg.size < 2 or pn.size != tg.size:
        return tg, pn

    step = float(tg[1] - tg[0])
    if abs(step) < 1e-9:
        return tg, pn

    shift_bins = int(np.round(float(rotate_deg) / step))
    pn2 = np.roll(pn, shift_bins)
    return tg, pn2


# ================== JSON PACKET ==================

def make_packet(X: np.ndarray, state: Dict[str, Any]) -> str:
    M, L = X.shape

    fc_hz = float(state["fc_hz"])

    doa_deg = None
    conf = None
    theta_grid_deg = []
    P_norm = []

    fft_freq_hz = []
    fft_mag_db = []
    fft_ch_used = int(state["fft_channel"])

    signal_present = False
    band_peak_db = -200.0
    doa_sig_power_lin = 0.0

    doa_offset_hz = float(state["doa_offset_hz"])
    doa_bw_hz = float(state["doa_bw_hz"])
    gate_th_db = float(state["gate_th_db"])

    rf_agc_channels: List[Dict[str, Any]] = []
    band_peaks_ch: List[float] = []

    if state["doa_enabled"] or state["spectrum_enabled"]:
        f_tmp, mdb_tmp, ch_used = compute_rf_fft(
            X, FS, fc_hz,
            int(state["fft_points"]), int(state["fft_downsample"]),
            int(state["fft_channel"])
        )
        band_peak_db = compute_band_peak_db(
            f_tmp, mdb_tmp, fc_hz, doa_offset_hz, doa_bw_hz
        )
        signal_present = (band_peak_db > gate_th_db)

        state["band_peak_db"] = float(band_peak_db)
        state["gate_th_db"] = float(gate_th_db)

        try:
            band_peaks_ch = compute_band_peak_db_per_channel(
                X, FS, fc_hz,
                int(state["fft_points"]), int(state["fft_downsample"]),
                doa_offset_hz, doa_bw_hz
            )
            if not isinstance(band_peaks_ch, list):
                band_peaks_ch = list(band_peaks_ch)
        except Exception:
            band_peaks_ch = []

        global _G_AGC_PER_CH
        if (_G_AGC_PER_CH is not None):
            try:
                targets = state.get("rf_agc_target_db", [])
                if isinstance(targets, list):
                    for i in range(min(len(targets), len(_G_AGC_PER_CH))):
                        try:
                            _G_AGC_PER_CH[i].set_target(float(targets[i]))
                        except Exception:
                            pass

                ch_en = state.get("rf_agc_ch_enabled", [])
                for ch in range(min(len(band_peaks_ch), len(_G_AGC_PER_CH))):
                    enabled = True
                    if isinstance(ch_en, list) and ch < len(ch_en):
                        enabled = bool(ch_en[ch])

                    if (not bool(state.get("rf_agc_enabled", False))) or (not enabled):
                        rf_agc_channels.append({
                            "ch": int(ch),
                            "enabled": False,
                            "band_peak_db": float(band_peaks_ch[ch]),
                            "att_db": 0.0,
                            "err_db": 0.0,
                            "target_db": float(state.get("rf_agc_target_db", [-75.0] * NUM_CH)[ch])
                            if isinstance(state.get("rf_agc_target_db", None), list) else -75.0,
                            "updated": 0.0,
                        })
                        continue

                    info = dict(_G_AGC_PER_CH[ch].update(
                        float(band_peaks_ch[ch]),
                        signal_present=(float(band_peaks_ch[ch]) > gate_th_db)
                    ))
                    info["ch"] = int(ch)
                    info["enabled"] = True
                    rf_agc_channels.append(info)

            except Exception:
                rf_agc_channels = []

        if state["spectrum_enabled"]:
            fft_freq_hz = f_tmp.tolist()
            fft_mag_db = mdb_tmp.tolist()
            fft_ch_used = int(ch_used)

    if state["doa_enabled"] and signal_present:
        cutoff = doa_bw_hz * 0.5

        h = state["_fir_cache"]
        if h is None:
            h = design_lowpass_fir(DEFAULT_FIR_TAPS, cutoff, FS)
            state["_fir_cache"] = h
            state["_fir_cutoff_cache"] = cutoff

        Xnb, new_phase = narrowband_extract(
            X, FS, doa_offset_hz, h, float(state["_mix_phase"])
        )
        state["_mix_phase"] = new_phase
        doa_sig_power_lin = float(np.mean(np.abs(Xnb) ** 2))

        radius_m = float(state.get("uca_radius_m", UCA_RADIUS_M))
        n_ant = int(state.get("num_antennas", Xnb.shape[0]))
        n_ant = max(2, min(int(Xnb.shape[0]), n_ant))

        uca_order = [0, 4, 3, 2, 1]
        Xnb_use = Xnb[uca_order[:n_ant], :]

        doa_algo = str(state.get("doa_algo", DEFAULT_DOA_ALGO)).strip().lower()
        tg = None
        pn = None

        fc_eff_hz = float(fc_hz) + float(doa_offset_hz)

        if doa_algo == "uca_esprit":
            if state.get("_doa_py_uca") is None:
                state["_doa_py_uca"] = _build_doa_py_uca(n_ant, radius_m)
            out = _doa_py_uca_esprit(Xnb_use, state.get("_doa_py_uca"), fc_eff_hz, NUM_SIGNAL)
            if out is not None and isinstance(out, (tuple, list)) and len(out) >= 2:
                doa_deg, conf = out[0], out[1]

        elif doa_algo == "phasefit_uca":
            doa_deg, conf, pn = doa_phasefit_uca_from_snapshot(
                Xnb_use, fc_eff_hz, radius_m, _theta_grids_deg
            )
            tg = _theta_grids_deg

        elif doa_algo == "music_1d_uca":
            doa_deg, conf, tg, pn = music_1d_uca(
                Xnb_use, fc_eff_hz, radius_m, NUM_SIGNAL,
                THETA_MIN_DEG, THETA_MAX_DEG, THETA_STEP_DEG
            )

        elif doa_algo == "phase_prob_uca":
            coh_w = None
            if bool(state.get("doa_prob_use_coh", True)):
                dbg = state.get("_phase_debug_cache", None)
                if isinstance(dbg, dict) and isinstance(dbg.get("coh", None), list):
                    try:
                        coh_all = np.asarray(dbg["coh"], dtype=np.float32).ravel()
                        coh_w = coh_all[uca_order[:n_ant]]
                    except Exception:
                        coh_w = None

            doa_deg, conf_val, tg, pth = doa_prob_phase_uca_from_snapshot(
                Xnb_use,
                fc_eff_hz,
                radius_m,
                _theta_grids_deg,
                beta=float(state.get("doa_prob_beta", 6.0)),
                coh_weights=coh_w,
            )
            conf = conf_val
            pn = pth

        elif doa_algo == "phase_first_strong_prob_uca":
            ref_ch = 0
            coh_w = None
            dbg = state.get("_phase_debug_cache", None)
            if isinstance(dbg, dict) and isinstance(dbg.get("coh", None), list):
                try:
                    coh_all = np.asarray(dbg["coh"], dtype=np.float32).ravel()
                    coh_w = coh_all[uca_order[:n_ant]]
                except Exception:
                    coh_w = None

            doa_deg, conf_val, tg, pth = doa_phase_first_strong_prob_uca(
                Xnb_use,
                fc_eff_hz,
                radius_m,
                _theta_grids_deg,
                ref_ch=ref_ch,
                beta=float(state.get("doa_prob_beta", 14.0)),
                coh_weights=coh_w,
                power_gamma=float(state.get("doa_power_gamma", 1.0)),
                coh_gamma=float(state.get("doa_coh_gamma", 2.0)),
                drop_coh_below=float(state.get("doa_drop_coh_below", 0.55)),
            )
            conf = conf_val
            pn = pth

        elif doa_algo == "mf_ps_tdoa_prob_uca":
            ref_ch = 0
            coh_w = None
            dbg = state.get("_phase_debug_cache", None)
            if isinstance(dbg, dict) and isinstance(dbg.get("coh", None), list):
                try:
                    coh_all = np.asarray(dbg["coh"], dtype=np.float32).ravel()
                    coh_w = coh_all[uca_order[:n_ant]]
                except Exception:
                    coh_w = None

            doa_deg, conf_val, tg, pth = doa_mf_ps_tdoa_prob_uca(
                Xnb_use,
                FS,
                fc_eff_hz,
                radius_m,
                _theta_grids_deg,
                ref_ch=ref_ch,
                k_tones=int(state.get("mf_k_tones", 5)),
                tone_span_hz=float(state.get("mf_tone_span_hz", max(4000.0, 0.8 * doa_bw_hz))),
                beta=float(state.get("mf_beta", 12.0)),
                sigma_tau_ns=float(state.get("mf_sigma_tau_ns", 1.5)),
                power_gamma=float(state.get("mf_power_gamma", 1.0)),
                coh_weights=coh_w,
            )

            # ===============================
            # ✅ EMA smoothing on probability (PUT HERE)
            # ===============================
            if (tg is not None) and (pth is not None):
                p_theta = np.asarray(pth, dtype=np.float32).ravel()

                alpha = float(state.get("prob_ema_alpha", 0.35))
                prev = state.get("_prob_ema", None)

                if (prev is None) or (not isinstance(prev, np.ndarray)) or (prev.size != p_theta.size):
                    p_smooth = p_theta.astype(np.float32)
                else:
                    p_smooth = ((1.0 - alpha) * prev + alpha * p_theta).astype(np.float32)
                    p_smooth = p_smooth / (float(np.sum(p_smooth)) + 1e-30)

                state["_prob_ema"] = p_smooth

                # ✅ DOA from circular mean (use smoothed)
                doa_deg = circ_mean_from_prob(np.asarray(tg, dtype=np.float32), p_smooth)

                # ✅ CONF recompute from smoothed prob (entropy-based, avoids "1.00 always")
                eps = 1e-30
                H = -float(np.sum(p_smooth * np.log(p_smooth + eps)))
                Hmax = math.log(float(p_smooth.size) + eps)
                conf = float(1.0 - (H / (Hmax + eps)))
                conf = max(0.0, min(1.0, conf))

                pn = p_smooth  # <-- output spectrum uses smoothed
            else:
                conf = float(conf_val) if conf_val is not None else 0.0
                pn = pth


        else:
            if state.get("_doa_py_uca") is None:
                state["_doa_py_uca"] = _build_doa_py_uca(n_ant, radius_m)
            out = _doa_py_uca_rb_music(Xnb_use, state.get("_doa_py_uca"), fc_eff_hz, NUM_SIGNAL, _theta_grids_deg)
            if out is not None:
                try:
                    doa_deg, conf, tg, pn = out
                    if tg is not None:
                        tg = np.asarray(tg, dtype=np.float32)
                    if pn is not None:
                        pn = np.asarray(pn, dtype=np.float32)
                    if (tg is not None) and (pn is not None):
                        if tg.ndim != 1 or pn.ndim != 1 or tg.size != pn.size:
                            raise ValueError("Invalid spectrum shape from doa_py")
                except Exception as e:
                    print(f"[WARN] doa_py output invalid ({e}), fallback to internal MUSIC")
                    doa_deg, conf, tg, pn = music_1d_uca(
                        Xnb_use, fc_eff_hz, radius_m, NUM_SIGNAL,
                        THETA_MIN_DEG, THETA_MAX_DEG, THETA_STEP_DEG
                    )
            else:
                doa_deg, conf, tg, pn = music_1d_uca(
                    Xnb_use, fc_eff_hz, radius_m, NUM_SIGNAL,
                    THETA_MIN_DEG, THETA_MAX_DEG, THETA_STEP_DEG
                )

        if (tg is not None) and (pn is not None):
            tg2, pn2 = rotate_polar_spectrum(tg, pn, rotate_deg=180.0)
            theta_grid_deg = tg2.tolist()
            P_norm = pn2.tolist()
        else:
            theta_grid_deg = []
            P_norm = []

    doas_out = []
    confs_out = []

    if doa_deg is None:
        doas_out = []
    elif isinstance(doa_deg, (list, tuple, np.ndarray)):
        doas_out = [float(x) for x in np.asarray(doa_deg).ravel().tolist()]
    else:
        doas_out = [float(doa_deg)]

    if doas_out:
        doas_out = [doa_add_180(x) for x in doas_out]
        state["last_doa_deg"] = float(doas_out[0])

    if conf is None:
        confs_out = []
    elif isinstance(conf, (list, tuple, np.ndarray)):
        confs_out = [float(x) for x in np.asarray(conf).ravel().tolist()]
    else:
        confs_out = [float(conf)]

    packet = {
        "menuID": "DoAResult",
        "timestamp": datetime.now().isoformat(),

        "frequency_hz": float(fc_hz),
        "radius_m": float(state.get("uca_radius_m", UCA_RADIUS_M)),
        "fs_hz": float(FS),

        "num_channels": int(M),
        "num_snapshots": int(L),

        "stream_enabled": bool(state["stream_enabled"]),
        "doa_enabled": bool(state["doa_enabled"]),
        "spectrum_enabled": bool(state["spectrum_enabled"]),
        "tx_hz": float(state["tx_hz"]),

        "doa_offset_hz": float(doa_offset_hz),
        "doa_bw_hz": float(doa_bw_hz),

        "signal_present": bool(signal_present),
        "band_peak_db": float(band_peak_db),
        "gate_th_db": float(gate_th_db),

        "ch_db": [float(x) for x in band_peaks_ch] if isinstance(band_peaks_ch, list) else [],

        "phase_debug": state.get("_phase_debug_cache", None),

        "rf_agc": {
            "available": bool(_ATT_AGC_OK),
            "enabled": bool(state.get("rf_agc_enabled", False)) and (_G_AGC_PER_CH is not None),
            "channels": rf_agc_channels,
        },
        "scanner_att_db": float(state.get("scanner_att_db", DEFAULT_SCANNER_ATT_DB)),
        "doa_sig_power": float(doa_sig_power_lin),

        "num_sources": int(NUM_SIGNAL) if (state["doa_enabled"] and signal_present) else 0,
        "doas": doas_out,
        "confidence": confs_out,
        "doa_algo": str(state.get("doa_algo", DEFAULT_DOA_ALGO)),
        "theta_deg": theta_grid_deg,
        "spectrum": P_norm,

        "fft_channel": int(fft_ch_used),
        "fft_freq_hz": fft_freq_hz,
        "fft_mag_db": fft_mag_db,

        "nco_update_en": int(state["nco_update_en"]),
        "rf_range_hz": [MIN_RF_HZ, MAX_RF_HZ],
    }

    return json.dumps(packet) + "\n"


def make_heartbeat(state: Dict[str, Any]) -> str:
    packet = {
        "menuID": "DoAResult",
        "timestamp": datetime.now().isoformat(),
        "stream_enabled": bool(state["stream_enabled"]),
        "doa_enabled": bool(state["doa_enabled"]),
        "spectrum_enabled": bool(state["spectrum_enabled"]),
        "tx_hz": float(state["tx_hz"]),
        "frequency_hz": float(state["fc_hz"]),
        "fft_channel": int(state["fft_channel"]),
        "doa_offset_hz": float(state["doa_offset_hz"]),
        "doa_bw_hz": float(state["doa_bw_hz"]),
        "doa_algo": str(state.get("doa_algo", DEFAULT_DOA_ALGO)),
        "signal_present": False,
        "band_peak_db": -200.0,
        "gate_th_db": float(state["gate_th_db"]),
        "scanner_att_db": float(state.get("scanner_att_db", DEFAULT_SCANNER_ATT_DB)),
        "doa_sig_power": 0.0,
        "doas": [],
        "confidence": [],
        "theta_deg": [],
        "spectrum": [],
        "fft_freq_hz": [],
        "fft_mag_db": [],
        "nco_update_en": int(state["nco_update_en"]),
        "rf_range_hz": [MIN_RF_HZ, MAX_RF_HZ],
        "phase_debug": state.get("_phase_debug_cache", None),
    }
    return json.dumps(packet) + "\n"


# ================== TCP CLIENT HANDLER ==================

_TCP_CONNECTED = False
_TCP_LAST_PEER = ""


def serve_client(conn: socket.socket, addr: Tuple[str, int], nco_unused, state: Dict[str, Any]):
    """
    - ใช้ state ตัวเดียว (shared จาก main)
    - รับคำสั่ง -> capture IQ -> อัปเดต phase_debug cache -> make_packet -> ส่งให้ client
    """
    print(f"[INFO] Client connected from {addr[0]}:{addr[1]}")
    global _TCP_CONNECTED, _TCP_LAST_PEER
    _TCP_CONNECTED = True
    _TCP_LAST_PEER = f"{addr[0]}:{addr[1]}"

    conn.setblocking(False)

    state.setdefault("stream_enabled", bool(DEFAULT_STREAM_ENABLED))
    state.setdefault("doa_enabled", bool(DEFAULT_DOA_ENABLED))
    state.setdefault("spectrum_enabled", bool(DEFAULT_SPECTRUM_ENABLED))
    state.setdefault("doa_algo", str(DEFAULT_DOA_ALGO))
    state.setdefault("iq_swap", bool(DEFAULT_IQ_SWAP))
    state.setdefault("fft_points", int(FFT_POINTS))
    state.setdefault("fft_downsample", int(FFT_DOWNSAMPLE))
    state.setdefault("fft_channel", int(DEFAULT_FFT_CHANNEL))
    state.setdefault("tx_hz", float(DEFAULT_TX_HZ))
    state.setdefault("fc_hz", float(DEFAULT_FC_HZ))
    state.setdefault("nco_update_en", int(DEFAULT_UPDATE_EN))
    state.setdefault("doa_offset_hz", float(DEFAULT_DOA_OFFSET_HZ))
    state.setdefault("doa_bw_hz", float(DEFAULT_DOA_BW_HZ))
    state.setdefault("gate_th_db", float(DEFAULT_GATE_TH_DB))
    state.setdefault("rf_agc_enabled", bool(_ATT_AGC_OK))
    state.setdefault("rf_agc_ch_enabled", [bool(_ATT_AGC_OK)] * int(NUM_CH))
    state.setdefault("rf_agc_target_db", [-75.0] * int(NUM_CH))
    state.setdefault("scanner_att_db", float(DEFAULT_SCANNER_ATT_DB))
    state.setdefault("uca_radius_m", float(UCA_RADIUS_M))
    state.setdefault("num_antennas", int(NUM_CH))
    state.setdefault("_doa_py_uca", None)
    state.setdefault("_mix_phase", 0.0)
    state.setdefault("_fir_cache", None)
    state.setdefault("_fir_cutoff_cache", -1.0)
    state.setdefault("band_peak_db", -200.0)
    state.setdefault("last_doa_deg", 0.0)

    state.setdefault("phase_debug_enable", True)
    state.setdefault("phase_debug_ref_ch", 0)
    state.setdefault("phase_debug_interval_ms", 1000)
    state.setdefault("_phase_debug_last_ts", 0.0)
    state.setdefault("_phase_debug_cache", None)

    state.setdefault("doa_prob_use_coh", True)
    state.setdefault("doa_prob_beta", 14.0)
    state.setdefault("doa_power_gamma", 1.0)
    state.setdefault("doa_coh_gamma", 2.0)
    state.setdefault("doa_drop_coh_below", 0.55)

    state.setdefault("mf_k_tones", 5)
    state.setdefault("mf_tone_span_hz", 16000.0)
    state.setdefault("mf_beta", 12.0)
    state.setdefault("mf_sigma_tau_ns", 1.5)
    state.setdefault("mf_power_gamma", 1.0)

    state.setdefault("prob_ema_alpha", 0.35)
    state.setdefault("_prob_ema", None)

    rxbuf = bytearray()
    iq_fd = open(IQ_DEV_PATH, "rb", buffering=0)

    try:
        next_tick = time.monotonic()

        while True:
            _try_recv_commands(conn, rxbuf, state, None)

            if bool(state.get("_disconnect_client", False)):
                state["_disconnect_client"] = False
                raise ConnectionResetError("disconnect client for tcp restart")

            if not bool(state.get("stream_enabled", True)):
                time.sleep(IDLE_SLEEP_SEC)
                continue

            hz = _clamp_tx_hz(float(state.get("tx_hz", DEFAULT_TX_HZ)))
            state["tx_hz"] = hz
            period = 1.0 / hz

            now = time.monotonic()
            if now < next_tick:
                time.sleep(min(next_tick - now, IDLE_SLEEP_SEC))
                continue

            if now - next_tick > 2.0:
                next_tick = now + period
            else:
                next_tick += period

            if (not bool(state.get("doa_enabled", False))) and (not bool(state.get("spectrum_enabled", False))):
                _send_frame_drop(conn, make_heartbeat(state))
                continue

            X = capture_block_from_fd(iq_fd, BLOCK_BYTES, bool(state.get('iq_swap', DEFAULT_IQ_SWAP)))
            if X.shape[1] > NUM_SAMPLES:
                X = X[:, :NUM_SAMPLES]

            if bool(state.get("phase_debug_enable", False)):
                now2 = time.monotonic()
                last2 = float(state.get("_phase_debug_last_ts", 0.0))
                itv2 = float(state.get("phase_debug_interval_ms", 1000)) / 1000.0
                if (now2 - last2) >= itv2:
                    state["_phase_debug_last_ts"] = now2
                    try:
                        refch = int(state.get("phase_debug_ref_ch", 0))
                        dbg = calc_phase_debug(X, ref_ch=refch)
                        dbg["timestamp"] = datetime.now().isoformat()
                        state["_phase_debug_cache"] = dbg
                    except Exception:
                        pass

            pkt = make_packet(X, state)
            _send_frame_drop(conn, pkt)

    except (BrokenPipeError, ConnectionResetError):
        print(f"[WARN] Client {addr} disconnected")
    except Exception as e:
        import traceback
        print(f"[ERROR] Exception for client {addr}: {e}")
        print(traceback.format_exc())
    finally:
        try:
            iq_fd.close()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass
        _TCP_CONNECTED = False
        print(f"[INFO] Connection closed: {addr[0]}:{addr[1]}")


# ================== NET HELPERS ==================

def get_iface_ipv4_ioctl(ifname: str) -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ifreq = struct.pack('256s', ifname[:15].encode('utf-8'))
        res = fcntl.ioctl(s.fileno(), 0x8915, ifreq)  # SIOCGIFADDR
        return socket.inet_ntoa(res[20:24])
    except Exception:
        return ""


def oled_algo_name_from_state(state: dict) -> str:
    a = str(state.get("doa_algo", "")).lower()
    if a in ("music_1d_uca", "music_std", "music"):
        return "MUSIC-STD"
    elif a in ("uca_rb_music", "music_rb"):
        return "MUSIC-RB"
    elif a in ("uca_esprit", "esprit"):
        return "ESPRIT-Peak"
    else:
        return "UNKNOWN"

# ================== MAIN (REFACTORED) ==================

def _make_default_state() -> Dict[str, Any]:
    """Create shared runtime state (ALWAYS created)."""
    state: Dict[str, Any] = {
        "fc_hz": DEFAULT_FC_HZ,
        "doa_offset_hz": DEFAULT_DOA_OFFSET_HZ,
        "doa_bw_hz": DEFAULT_DOA_BW_HZ,
        "gate_th_db": DEFAULT_GATE_TH_DB,

        "stream_enabled": DEFAULT_STREAM_ENABLED,
        "doa_enabled": DEFAULT_DOA_ENABLED,
        "spectrum_enabled": DEFAULT_SPECTRUM_ENABLED,

        "fft_points": DEFAULT_FFT_POINTS,
        "fft_downsample": DEFAULT_FFT_DOWNSAMPLE,
        "fft_channel": DEFAULT_FFT_CHANNEL,

        "doa_algo": DEFAULT_DOA_ALGO,
        "uca_radius_m": UCA_RADIUS_M,
        "num_antennas": NUM_CH,

        "tx_hz": DEFAULT_TX_HZ,
        "nco_update_en": DEFAULT_UPDATE_EN,

        "_fir_cache": None,
        "_fir_cutoff_cache": None,
        "_mix_phase": 0.0,
        "_doa_py_uca": None,

        "band_peak_db": -200.0,
        "last_doa_deg": 0.0,

        "_last_band_apply_hz": -1,
        "_last_band_apply_ts": 0.0,

        "_tcp_restart": False,
        "_tcp_bind_host": TCP_HOST,
        "_tcp_restart_reason": "",
        "_disconnect_client": False,

        "phase_debug_enable": True,
        "phase_debug_ref_ch": 0,
        "phase_debug_interval_ms": 1000,
        "_phase_debug_last_ts": 0.0,
        "_phase_debug_cache": None,

        "rf_mts_bin": DEFAULT_RF_MTS_BIN,
        "mts_setfreq": 1,
        "mts_init_once": 1,
        "mts_tiles": DEFAULT_MTS_TILES,
        "mts_gpiochip": DEFAULT_GPIOCHIP,
        "mts_lmk_reset": DEFAULT_LMK_RESET,
        "mts_lmk_sync": DEFAULT_LMK_SYNC,
        "mts_spidev": DEFAULT_SPI_DEV,
        "mts_do_lmk_init": DEFAULT_DO_LMK_INIT,
        "mts_sysref_shots": DEFAULT_SYSREF_SHOTS,
        "mts_sysref_pulse": DEFAULT_SYSREF_PULSE,
        "mts_sysref_repeat": DEFAULT_SYSREF_REPEAT,
        "mts_sysref_delay_us": DEFAULT_SYSREF_DELAY_US,

        "nco_base": DEFAULT_NCO_BASE_STR,
        "nco_fs_hz": DEFAULT_NCO_FS_STR,
        "nco_phase": DEFAULT_NCO_PHASE,
        "nco_rst": DEFAULT_NCO_RST,
        "post_mts_delay_ms": DEFAULT_POST_MTS_DELAY_MS,

        "doa_prob_use_coh": True,
        "doa_prob_beta": 14.0,
        "doa_power_gamma": 1.0,
        "doa_coh_gamma": 2.0,
        "doa_drop_coh_below": 0.55,

        "mf_k_tones": 5,
        "mf_tone_span_hz": 16000.0,
        "mf_beta": 12.0,
        "mf_sigma_tau_ns": 1.5,
        "mf_power_gamma": 1.0,

        # ================== BOOT / VERSION INFO ==================
        "_sw_version": "unknown",
        "_sw_deploy_date": "",
        "_boot_time": time.monotonic(),
        # OTA status (listener will populate)
        "_ota": None,
    }
    return state


def _load_version_into_state(state: Dict[str, Any]) -> None:
    """Load software version info at boot into state."""
    try:
        sw = load_sw_version()
        if isinstance(sw, dict):
            state["_sw_version"] = sw.get("version", "unknown")
            state["_sw_deploy_date"] = sw.get("deploy_date", "")
        else:
            state["_sw_version"] = "unknown"
            state["_sw_deploy_date"] = ""
    except Exception:
        state["_sw_version"] = "unknown"
        state["_sw_deploy_date"] = ""


def _init_att_agc_global() -> None:
    """Initialize ATT/AGC globals if available. Safe to fail without breaking system."""
    global _G_AGC_PER_CH, _G_ATT_MAP
    _G_AGC_PER_CH = None
    _G_ATT_MAP = None

    if not _ATT_AGC_OK:
        return

    try:
        att_map = build_att_map(2)
        _G_ATT_MAP = att_map

        # set default scanner attenuation (optional)
        try:
            if SCANNER_ATT_INDEX in att_map:
                att_map[SCANNER_ATT_INDEX].set_db(float(DEFAULT_SCANNER_ATT_DB))
        except Exception:
            pass

        agcs = []
        for ch in range(int(NUM_CH)):
            agc = AttAgc(
                att_map,
                group="one",
                att_index=int(ch + 1),
                target_db=-85.0,
                deadband_db=0.8,
                kp=0.15,
                ki=0.02,
                avg_len=4,
                require_signal_present=True,
            )
            agcs.append(agc)

        _G_AGC_PER_CH = agcs
        print(f"[INFO] RF ATT AGC enabled: per-channel {len(_G_AGC_PER_CH)} channels")

    except Exception as e:
        _G_AGC_PER_CH = None
        _G_ATT_MAP = None
        print(f"[WARN] RF ATT AGC init failed, disabled: {e}")


def _oled_line3_from_state(state: Dict[str, Any]) -> str:
    """Default line3 when no OTA override."""
    band_db = float(state.get("band_peak_db", -200.0))
    gate_db = float(state.get("gate_th_db", DEFAULT_GATE_TH_DB))
    return f"SIGNAL {band_db:0.1f}dB (th {gate_db:0.0f})"[:64]


def oled_worker(oled_obj, state: Dict[str, Any], hz: float = 2.0) -> None:
    global _TCP_CONNECTED

    interval = 1.0 / max(0.2, float(hz))
    last_ip_update = 0.0
    ip_l1 = ""
    ip_l2 = ""

    while True:
        try:
            now = time.monotonic()

            # -------------------------------
            # Periodic IP update
            # -------------------------------
            if (now - last_ip_update) >= 5.0:
                last_ip_update = now
                ip_l1 = get_iface_ipv4_ioctl("end0")
                ip_l2 = get_iface_ipv4_ioctl("end1")
                oled_obj.set_ip(1, ip_l1 if ip_l1 else "", True if ip_l1 else False)
                oled_obj.set_ip(2, ip_l2 if ip_l2 else "", True if ip_l2 else False)

            # =========================================================
            # BOOT / OLED WARMUP DISPLAY
            # =========================================================
            warmup_until = state.get("_oled_ready_ts", None)  # ตั้งตอน start oled = now + 5
            if isinstance(warmup_until, (int, float)) and now < float(warmup_until):
                ver = state.get("_sw_version", "unknown")
                oled_obj.set_line1_left("DF PROJECT")
                oled_obj.set_line1_right("")
                oled_obj.set_line2_left("BOOTING OLED...")
                oled_obj.set_line2_right("")
                oled_obj.set_line3(f"Version {ver}"[:64])
                oled_obj.send(send_twice=True, delay_s=0.2)
                time.sleep(interval)
                continue

            # -------------------------------
            # OTA override (FULL SCREEN)
            # -------------------------------
            ota = state.get("_ota", None)

            stage = ""
            msg = ""
            prog = None
            ota_active = False

            if isinstance(ota, dict):
                # รองรับทั้ง schema:
                stage = str(ota.get("stage", ota.get("state", ""))).strip()
                msg   = str(ota.get("message", ota.get("msg", ""))).strip()
                prog  = ota.get("progress", ota.get("pct", None))

                stale_sec = 30.0
                ts = ota.get("ts_monotonic", None)
                if isinstance(ts, (int, float)) and (now - float(ts)) <= stale_sec:
                    if stage or msg:
                        ota_active = True

            if ota_active:
                # 🔴 OTA MODE: override line1/2/3 ชัดๆ
                oled_obj.set_line1_left("=== OTA UPDATE ===")
                oled_obj.set_line1_right("")

                if prog is not None:
                    try:
                        p = int(float(prog))
                        p = max(0, min(100, p))
                        oled_obj.set_line2_left(stage[:16] if stage else "Updating")
                        oled_obj.set_line2_right(f"{p:3d}%")
                    except Exception:
                        oled_obj.set_line2_left(stage[:16] if stage else "Updating")
                        oled_obj.set_line2_right("")
                else:
                    oled_obj.set_line2_left(stage[:16] if stage else "Updating")
                    oled_obj.set_line2_right("")

                oled_obj.set_line3((msg if msg else "Updating...")[:64])
                oled_obj.send(send_twice=True, delay_s=0.2)
                time.sleep(interval)
                continue  # สำคัญ: ไม่ให้ DOA เขียนทับ OTA

            # -------------------------------
            # Main info (normal screen)
            # -------------------------------
            fc_hz = float(state.get("fc_hz", DEFAULT_FC_HZ))
            off_hz = float(state.get("doa_offset_hz", DEFAULT_DOA_OFFSET_HZ))
            current_mhz = (fc_hz + off_hz) / 1e6

            doa_deg = float(state.get("last_doa_deg", 0.0)) % 360.0
            algo_disp = oled_algo_name_from_state(state)

            oled_obj.set_line1_left(f"{current_mhz:0.4f} MHz")
            oled_obj.set_line1_right(f"DOA {doa_deg:6.1f}")
            oled_obj.set_line2_left(f"{algo_disp[:16]}")
            oled_obj.set_line2_right("Cli:Connected" if _TCP_CONNECTED else "Cli:Disconn")

            line3 = _oled_line3_from_state(state)
            oled_obj.set_line3(str(line3)[:64])
            oled_obj.send(send_twice=True, delay_s=0.2)

        except Exception:
            pass

        time.sleep(interval)

def _start_oled_if_available(state: Dict[str, Any]):
    if not _OLED_OK:
        return None

    try:
        oled = OledSpiDF(dev="/dev/spidev1.0", speed=1_000_000, mode=0)

        # mark OLED not ready yet
        warmup_sec = 5.0
        state["_oled_ready_ts"] = time.monotonic() + warmup_sec

        threading.Thread(
            target=oled_worker,
            args=(oled, state, 2.0),
            daemon=True
        ).start()

        print(f"[INFO] OLED worker started (warmup {warmup_sec:.1f}s)")
        return oled

    except Exception as e:
        print(f"[WARN] OLED disabled: {e}")
        return None



def _make_tcp_server(bind_host: str, port: int) -> socket.socket:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((bind_host, int(port)))
    s.listen(1)
    s.settimeout(1.0)
    return s


def _start_link_monitors_if_possible(conn: socket.socket):
    """Start LinkMonitor(s) for end0/end1; returns list of monitors to stop later."""
    mons = []
    try:
        if _CONNMAN_OK and LinkMonitor is not None:
            for ifname in ("end0", "end1"):
                mon = LinkMonitor(
                    ifname,
                    interval_s=0.5,
                    on_change=lambda i, up, _c=conn: _send_link_event(_c, i, up)
                )
                mon.start()
                mons.append(mon)
    except Exception as e:
        for m in mons:
            try:
                m.stop()
            except Exception:
                pass
        mons = []
        print(f"[WARN] link monitor start failed: {e}")
    return mons


def _stop_link_monitors(mons) -> None:
    for m in mons:
        try:
            m.stop()
        except Exception:
            pass


def _run_tcp_accept_loop(state: Dict[str, Any]) -> None:
    """TCP accept loop with restart support."""
    global _TCP_CONNECTED, _TCP_LAST_PEER
    _TCP_CONNECTED = False
    _TCP_LAST_PEER = ""

    srv = _make_tcp_server(TCP_HOST, TCP_PORT)
    print(f"[INFO] TCP server bound on {TCP_HOST}:{TCP_PORT}")

    try:
        while True:
            # restart logic
            if bool(state.get("_tcp_restart", False)):
                state["_tcp_restart"] = False
                bind_host = str(state.get("_tcp_bind_host", TCP_HOST)).strip() or TCP_HOST
                reason = str(state.get("_tcp_restart_reason", ""))
                try:
                    srv.close()
                except Exception:
                    pass
                time.sleep(0.2)
                srv = _make_tcp_server(bind_host, TCP_PORT)
                print(f"[INFO] TCP server restarted: {bind_host}:{TCP_PORT} ({reason})")

            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue

            _TCP_CONNECTED = True
            _TCP_LAST_PEER = f"{addr[0]}:{addr[1]}"

            link_mons = _start_link_monitors_if_possible(conn)
            try:
                serve_client(conn, addr, None, state)
            finally:
                _TCP_CONNECTED = False
                _stop_link_monitors(link_mons)
                try:
                    conn.close()
                except Exception:
                    pass

    finally:
        try:
            srv.close()
        except Exception:
            pass


def _print_boot_banner() -> None:
    print(f"[INFO] doa_music_server listening on {TCP_HOST}:{TCP_PORT}")
    print(f"[INFO] Using IQ device {IQ_DEV_PATH}, FS={FS} Hz, default FC={DEFAULT_FC_HZ} Hz, R={UCA_RADIUS_M} m")
    print(f"[INFO] RF clamp range: {MIN_RF_HZ} .. {MAX_RF_HZ} Hz")
    print(f"[INFO] Default: stream={DEFAULT_STREAM_ENABLED}, doa={DEFAULT_DOA_ENABLED}, spectrum={DEFAULT_SPECTRUM_ENABLED}")
    print(f"[INFO] Default tone: offset={DEFAULT_DOA_OFFSET_HZ} Hz, BW={DEFAULT_DOA_BW_HZ} Hz, gate_th_db={DEFAULT_GATE_TH_DB} dB")
    print(f"[INFO] Default tx_hz={DEFAULT_TX_HZ}")
    print("[INFO] Frequency changes: using rfsoc_adc_mts --setfreq (MTS -> delay -> NCO)")


def main():
    _print_boot_banner()

    # 1) init globals (AGC/ATT)
    _init_att_agc_global()

    # 2) create shared state (ALWAYS)
    state = _make_default_state()
    # 3) load version into state at boot (for OLED + client UI)
    _load_version_into_state(state)

    # 4) start OTA status listener (agent -> unix sock -> update state["_ota"])
    try:
        start_ota_status_listener(state)
    except Exception as e:
        print(f"[WARN] OTA status listener failed to start: {e}")

    # 5) start OLED (optional)
    oled = _start_oled_if_available(state)
    time.sleep(10.0)

    # 6) run TCP loop (blocking)
    try:
        _run_tcp_accept_loop(state)
    finally:
        # cleanup
        if oled is not None:
            try:
                oled.close()
            except Exception:
                pass


if __name__ == "__main__":
    main()
