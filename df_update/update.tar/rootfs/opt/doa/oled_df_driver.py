#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
oled_df_driver.py
OLED SPI driver (Linux spidev -> STM32 SPI)

Proto:
  BUFFERSIZE=256
  tx[0]=0xAA, tx[1]=0xBB
  tx[254]=MESSAGE_ID (inc each send)
  tx[255]=CHECKSUM (XOR 0..254)

Layout (fixed offsets, STM32 render):
  Line1: left/right (32 bytes each)
  Line2: left/right (32 bytes each)
  Line3: full (64 bytes)
  Line4: IP bytes + link flags (LAN1/LAN2) in fixed offsets

Extra features (self-contained, no changes to other files):
  - HW reset once before opening SPI (gpioset gpiochip3 line88)
  - Auto-recover on SPI error (reset + reopen SPI + retry once)
  - Manual reset callable anytime: oled.reset()
"""

import time
import spidev
import subprocess
import threading

BUFFERSIZE = 256
LINESIZE   = 64

# --- same offsets as your iClock OLED protocol ---
LINE1_L = 2
LINE1_R = 34
LINE2_L = 66
LINE2_R = 98
LINE3   = 130

IP1_0 = 194
IP1_1 = 195
IP1_2 = 196
IP1_3 = 197
IP2_0 = 198
IP2_1 = 199
IP2_2 = 200
IP2_3 = 201
ETH1  = 202
ETH2  = 203

MSG_ID_IDX = 254
CHK_IDX    = 255


class OledSpiDF:
    def __init__(
        self,
        dev="/dev/spidev1.0",
        speed=1_000_000,
        mode=0,
        # ---- GPIO reset config ----
        reset_enable=False,
        reset_gpio_chip=3,
        reset_gpio_line=88,
        reset_low_s=0.010,
        reset_high_s=0.050,
        # anti-spam reset when SPI error keeps happening
        min_reset_interval_s=0.50,
    ):
        self.dev = str(dev)
        self.speed = int(speed)
        self.mode = int(mode)

        self.reset_enable = bool(reset_enable)
        self.reset_gpio_chip = int(reset_gpio_chip)
        self.reset_gpio_line = int(reset_gpio_line)
        self.reset_low_s = float(reset_low_s)
        self.reset_high_s = float(reset_high_s)
        self.min_reset_interval_s = float(min_reset_interval_s)

        self._lock = threading.Lock()
        self._last_reset_t = 0.0

        self.spi = None
        self.tx = bytearray([0x00] * BUFFERSIZE)
        self._msg_id = 0

        # header
        self.tx[0] = 0xAA
        self.tx[1] = 0xBB

        # ✅ reset once before opening SPI (as requested)
        if self.reset_enable:
            self._hw_reset(force=True)

        self._open_spi()

    # ---------------- SPI open/close ----------------
    def _open_spi(self):
        bus, cs = self._parse_spidev(self.dev)
        spi = spidev.SpiDev()
        spi.open(bus, cs)
        spi.max_speed_hz = self.speed
        spi.mode = self.mode
        spi.bits_per_word = 8
        self.spi = spi

    def _close_spi(self):
        if self.spi is not None:
            try:
                self.spi.close()
            except Exception:
                pass
            self.spi = None

    def close(self):
        with self._lock:
            self._close_spi()

    @staticmethod
    def _parse_spidev(dev: str):
        # "/dev/spidev1.0"
        name = dev.strip().split("/")[-1]
        if not name.startswith("spidev") or "." not in name:
            raise ValueError(f"Invalid spidev path: {dev}")
        s = name[len("spidev"):]  # "1.0"
        bus_s, cs_s = s.split(".", 1)
        return int(bus_s), int(cs_s)

    # ---------------- HW reset (gpioset) ----------------
    def _hw_reset(self, force=False):
        """
        Toggle reset GPIO via gpioset:
          gpioset <chip> <line>=0 ; sleep ; gpioset <chip> <line>=1 ; sleep
        Rate-limited unless force=True.
        """
        if not self.reset_enable:
            return

        now = time.monotonic()
        if (not force) and ((now - self._last_reset_t) < self.min_reset_interval_s):
            return

        # do reset
        try:
            subprocess.run(["gpioset", str(self.reset_gpio_chip), f"{self.reset_gpio_line}=0"], check=True)
            time.sleep(self.reset_low_s)
            subprocess.run(["gpioset", str(self.reset_gpio_chip), f"{self.reset_gpio_line}=1"], check=True)
            time.sleep(self.reset_high_s)
            self._last_reset_t = time.monotonic()
        except Exception as e:
            # don't crash application if reset tool missing; keep going
            # (SPI might still work)
            print(f"[WARN] OLED reset failed: {e}")

    def reset(self):
        """
        PUBLIC: user can call reset anytime.
        This does: hw reset + reopen SPI
        """
        with self._lock:
            self._hw_reset(force=True)
            self._close_spi()
            self._open_spi()

    # ---------------- text write helpers ----------------
    def _write_ascii(self, index: int, text: str, maxlen: int):
        b = (text or "").encode("ascii", errors="ignore")[:maxlen]
        for i in range(maxlen):
            self.tx[index + i] = b[i] if i < len(b) else 0x00

    def set_line1_left(self, text: str):
        with self._lock:
            self._write_ascii(LINE1_L, text, 32)

    def set_line1_right(self, text: str):
        with self._lock:
            self._write_ascii(LINE1_R, text, 32)

    def set_line2_left(self, text: str):
        with self._lock:
            self._write_ascii(LINE2_L, text, 32)

    def set_line2_right(self, text: str):
        with self._lock:
            self._write_ascii(LINE2_R, text, 32)

    def set_line3(self, text: str):
        with self._lock:
            self._write_ascii(LINE3, text, 64)

    # ---------------- IP + link flags ----------------
    def set_ip(self, lan: int, ip: str, connected: bool):
        parts = (ip or "0.0.0.0").split(".")
        if len(parts) != 4:
            return
        try:
            a, b, c, d = [int(x) & 0xFF for x in parts]
        except Exception:
            return

        with self._lock:
            if int(lan) == 1:
                self.tx[IP1_0:IP1_3 + 1] = bytes([a, b, c, d])
                self.tx[ETH1] = 1 if connected else 0
            elif int(lan) == 2:
                self.tx[IP2_0:IP2_3 + 1] = bytes([a, b, c, d])
                self.tx[ETH2] = 1 if connected else 0

    # ---------------- packet finalize + send ----------------
    def _update_msg_id(self):
        self._msg_id = (self._msg_id + 1) & 0xFF
        self.tx[MSG_ID_IDX] = self._msg_id

    def _update_checksum(self):
        chk = 0
        for i in range(CHK_IDX):  # 0..254
            chk ^= self.tx[i]
        self.tx[CHK_IDX] = chk & 0xFF

    def _xfer2_once(self):
        if self.spi is None:
            raise RuntimeError("SPI not open")
        self.spi.xfer2(self.tx)

    def send(self, send_twice=True, delay_s=0.2):
        """
        Send packet to STM32.
        Auto-recover on SPI error (reset + reopen + retry once) ONLY when needed.
        NOTE: On retry, it resends the SAME tx (same msg_id/checksum) to avoid skipping IDs.
        """
        with self._lock:
            # ensure header always
            self.tx[0] = 0xAA
            self.tx[1] = 0xBB

            # update id/checksum ONCE per call
            self._update_msg_id()
            self._update_checksum()

            # --- first attempt ---
            try:
                self._xfer2_once()
                if send_twice:
                    time.sleep(float(delay_s))
                    self._xfer2_once()
                return
            except Exception as e:
                # --- recover only when SPI error really happened ---
                print(f"[WARN] OLED SPI error: {e} -> reset/reopen and retry once")

                # reset (rate-limited) + reopen
                self._hw_reset(force=False)
                self._close_spi()
                try:
                    self._open_spi()
                except Exception as e2:
                    print(f"[ERROR] OLED reopen SPI failed: {e2}")
                    raise

                # --- retry once (same tx buffer) ---
                self._xfer2_once()
                if send_twice:
                    time.sleep(float(delay_s))
                    self._xfer2_once()
