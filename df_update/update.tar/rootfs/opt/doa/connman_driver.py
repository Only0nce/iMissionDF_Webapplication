# connman_driver.py
from __future__ import annotations

import os
import re
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional


class ConnmanError(RuntimeError):
    pass


def _run(cmd: List[str], timeout: int = 8) -> str:
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as e:
        raise ConnmanError(f"Command not found: {cmd[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise ConnmanError(f"Timeout running: {' '.join(cmd)}") from e

    out = (p.stdout or "").strip()
    err = (p.stderr or "").strip()
    if p.returncode != 0:
        msg = f"Command failed ({p.returncode}): {' '.join(cmd)}"
        if err:
            msg += f"\nSTDERR: {err}"
        if out:
            msg += f"\nSTDOUT: {out}"
        raise ConnmanError(msg)
    return out


def _read_file(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def _mac_of(ifname: str) -> str:
    mac = _read_file(f"/sys/class/net/{ifname}/address").lower()
    if not mac or mac == "00:00:00:00:00:00":
        raise ConnmanError(f"Cannot read MAC for interface: {ifname}")
    return mac


def _mac_compact(mac: str) -> str:
    return re.sub(r"[^0-9a-fA-F]", "", mac).lower()


def _carrier_of(ifname: str) -> Optional[int]:
    s = _read_file(f"/sys/class/net/{ifname}/carrier")
    if not s:
        return None
    try:
        return int(s)
    except ValueError:
        return None


def _operstate_of(ifname: str) -> str:
    return _read_file(f"/sys/class/net/{ifname}/operstate")


@dataclass
class ConnmanService:
    name: str
    service_id: str
    flags: str


class ConnmanManager:
    def __init__(self, connmanctl: str = "connmanctl"):
        self.connmanctl = connmanctl

    def services(self) -> List[ConnmanService]:
        out = _run([self.connmanctl, "services"])
        lines = [ln.rstrip() for ln in out.splitlines() if ln.strip()]
        svcs: List[ConnmanService] = []

        for ln in lines:
            tokens = ln.split()
            if len(tokens) < 2:
                continue
            service_id = tokens[-1]
            prefix = tokens[:-1]
            flags = prefix[0] if prefix else ""
            name = " ".join(prefix[1:]) if len(prefix) > 1 else ""
            svcs.append(ConnmanService(name=name, service_id=service_id, flags=flags))
        return svcs

    def find_service_for_interface(self, ifname: str) -> ConnmanService:
        mac = _mac_of(ifname)
        key = _mac_compact(mac)
        svcs = self.services()

        matches = [s for s in svcs if key in s.service_id.lower()]
        if not matches:
            eth_like = [s for s in svcs if s.service_id.lower().startswith("ethernet_")]
            if len(eth_like) == 1:
                return eth_like[0]
            raise ConnmanError(
                f"Cannot find connman service for {ifname} (mac={mac}). "
                f"Available: {[s.service_id for s in svcs]}"
            )

        if len(matches) > 1:
            cable = [m for m in matches if "cable" in m.service_id.lower()]
            if len(cable) == 1:
                return cable[0]
            raise ConnmanError(f"Multiple services match {ifname}: {[m.service_id for m in matches]}")

        return matches[0]

    def config_ipv4_manual(
        self,
        ifname: str,
        ip: str,
        netmask: str,
        gateway: Optional[str] = None,
        dns: Optional[List[str]] = None,
    ) -> Dict[str, str]:
        svc = self.find_service_for_interface(ifname)
        gw = gateway or "0.0.0.0"

        _run([self.connmanctl, "config", svc.service_id, "--ipv4", "manual", ip, netmask, gw])

        dns_clean: List[str] = []
        if dns:
            dns_clean = [d.strip() for d in dns if d and d.strip()]

        if dns_clean:
            _run([self.connmanctl, "config", svc.service_id, "--nameservers", *dns_clean])

        return {
            "ifname": ifname,
            "service_id": svc.service_id,
            "ip": ip,
            "netmask": netmask,
            "gateway": gw,
            "dns": " ".join(dns_clean),
        }

    def link_state(self, ifname: str) -> Dict[str, str]:
        carrier = _carrier_of(ifname)
        oper = _operstate_of(ifname)
        return {
            "ifname": ifname,
            "carrier": "" if carrier is None else str(carrier),
            "operstate": oper,
            "up": "1" if (carrier == 1 or oper.lower() == "up") else "0",
        }


class LinkMonitor:
    def __init__(
        self,
        ifname: str,
        interval_s: float = 0.5,
        on_change: Optional[Callable[[str, bool], None]] = None,
    ):
        self.ifname = ifname
        self.interval_s = max(0.1, float(interval_s))
        self.on_change = on_change
        self._stop = threading.Event()
        self._thr: Optional[threading.Thread] = None
        self._last: Optional[bool] = None

    def _read_up(self) -> bool:
        c = _carrier_of(self.ifname)
        if c is not None:
            return (c == 1)
        op = _operstate_of(self.ifname).lower()
        return op == "up"

    def start(self) -> None:
        if self._thr and self._thr.is_alive():
            return
        self._stop.clear()
        self._thr = threading.Thread(target=self._loop, daemon=True)
        self._thr.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thr:
            self._thr.join(timeout=2)

    def _loop(self) -> None:
        while not self._stop.is_set():
            up = self._read_up()
            if self._last is None:
                self._last = up
                if self.on_change:
                    self.on_change(self.ifname, up)
            elif up != self._last:
                self._last = up
                if self.on_change:
                    self.on_change(self.ifname, up)
            time.sleep(self.interval_s)
