#!/usr/bin/env python3
# att_agc.py
#
# Simple FFT-based AGC for PE43711 attenuators (0..31.75 dB, 0.25 dB step)
# - Uses band_peak_db (dBFS/bin from your compute_rf_fft) as feedback
# - Rate limited and with deadband to avoid hunting
#
# Usage:
#   from attctl import build_att_map
#   from att_agc import AttAgc
#   att_map = build_att_map(2)
#   agc = AttAgc(att_map, group="all")
#   agc.update(band_peak_db)

from __future__ import annotations
import time
from typing import Dict, Optional

# att_map type: {1..8: PE43711 instance with set_db()}
AttMap = Dict[int, object]

def _clamp(x: float, lo: float, hi: float) -> float:
    if x < lo: return lo
    if x > hi: return hi
    return x

def _qstep(db: float) -> float:
    return round(db / 0.25) * 0.25

class AttAgc:
    """
    PI-like AGC on attenuation in dB domain:
      err = (band_peak_db - target_db)
      att += Kp*err + Ki*int(err)
    where increasing att reduces band_peak_db.

    You can apply to:
      - group="all" : all 8
      - group="u31" : att 1..3
      - group="u32" : att 4..5
      - group="u33" : att 6..8
      - group="one" : only a single att_index

    Notes:
    - band_peak_db is whatever your compute_rf_fft outputs (dBFS/bin).
    - If your measurement is noisy, increase deadband or avg_len.
    """
    def __init__(
        self,
        att_map: AttMap,
        *,
        group: str = "all",
        att_index: int = 1,          # used when group="one"
        target_db: float = -55.0,    # desired band_peak_db
        deadband_db: float = 0.8,    # do nothing if |err| < deadband
        kp: float = 0.15,            # proportional gain (dB att per dB error)
        ki: float = 0.02,            # integrator gain
        i_limit: float = 20.0,       # clamp integrator term (in dB)
        min_att_db: float = 0.0,
        max_att_db: float = 31.75,
        step_limit_db: float = 1.0,  # max change per update (anti-jerk)
        update_period_s: float = 0.25,  # rate limit updates
        avg_len: int = 4,            # moving average length on band_peak_db
        require_signal_present: bool = True,
    ):
        self.att_map = att_map
        self.group = group
        self.att_index = int(att_index)

        self.target_db = float(target_db)
        self.deadband_db = float(deadband_db)
        self.kp = float(kp)
        self.ki = float(ki)
        self.i_limit = float(i_limit)
        self.min_att_db = float(min_att_db)
        self.max_att_db = float(max_att_db)
        self.step_limit_db = float(step_limit_db)
        self.update_period_s = float(update_period_s)
        self.avg_len = max(1, int(avg_len))
        self.require_signal_present = bool(require_signal_present)

        self._i = 0.0
        self._last_update = 0.0
        self._att_db = 0.0  # our internal "current" setting (single value for the group)
        self._avg_buf = []

        # init internal att_db from first channel if possible
        # (we can't read back from chip; keep software state)
        self._att_db = 0.0

    def set_target(self, target_db: float):
        self.target_db = float(target_db)

    def set_group(self, group: str, att_index: int = 1):
        self.group = str(group)
        self.att_index = int(att_index)

    def _indices(self):
        g = self.group.lower().strip()
        if g == "all":
            return [1,2,3,4,5,6,7,8]
        if g == "u31":
            return [1,2,3]
        if g == "u32":
            return [4,5]
        if g == "u33":
            return [6,7,8]
        if g == "one":
            n = int(self.att_index)
            if n < 1: n = 1
            if n > 8: n = 8
            return [n]
        # fallback
        return [1,2,3,4,5,6,7,8]

    def _apply_att(self, att_db: float):
        att_db = _qstep(_clamp(att_db, self.min_att_db, self.max_att_db))
        idxs = self._indices()
        for i in idxs:
            if i in self.att_map:
                self.att_map[i].set_db(att_db)
        self._att_db = att_db

    def force(self, att_db: float):
        """Force attenuation immediately (no rate limit)."""
        self._apply_att(att_db)
        self._last_update = time.monotonic()

    def update(
        self,
        band_peak_db: float,
        *,
        signal_present: Optional[bool] = None,
    ) -> Dict[str, float]:
        """
        Returns dict with AGC telemetry.
        """
        now = time.monotonic()

        if signal_present is None:
            signal_present = True

        if self.require_signal_present and (not bool(signal_present)):
            # Do not adapt when no signal (prevents ramping down noise)
            return {
                "att_db": float(self._att_db),
                "err_db": 0.0,
                "band_db": float(band_peak_db),
                "target_db": float(self.target_db),
                "integrator": float(self._i),
                "updated": 0.0,
            }

        # moving average
        self._avg_buf.append(float(band_peak_db))
        if len(self._avg_buf) > self.avg_len:
            self._avg_buf.pop(0)
        band_avg = sum(self._avg_buf) / float(len(self._avg_buf))

        # rate limit
        if (now - self._last_update) < self.update_period_s:
            return {
                "att_db": float(self._att_db),
                "err_db": float(band_avg - self.target_db),
                "band_db": float(band_avg),
                "target_db": float(self.target_db),
                "integrator": float(self._i),
                "updated": 0.0,
            }

        err = band_avg - self.target_db  # +err => too strong, increase ATT
        if abs(err) < self.deadband_db:
            self._last_update = now
            return {
                "att_db": float(self._att_db),
                "err_db": float(err),
                "band_db": float(band_avg),
                "target_db": float(self.target_db),
                "integrator": float(self._i),
                "updated": 0.0,
            }

        # integrator
        self._i += err
        self._i = _clamp(self._i, -self.i_limit, self.i_limit)

        delta = (self.kp * err) + (self.ki * self._i)

        # step limit to avoid jumps
        delta = _clamp(delta, -self.step_limit_db, self.step_limit_db)

        new_att = self._att_db + delta
        new_att = _clamp(new_att, self.min_att_db, self.max_att_db)

        self._apply_att(new_att)
        self._last_update = now

        return {
            "att_db": float(self._att_db),
            "err_db": float(err),
            "band_db": float(band_avg),
            "target_db": float(self.target_db),
            "integrator": float(self._i),
            "updated": 1.0,
        }
