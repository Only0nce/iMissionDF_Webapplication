#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rf_band_select.py
- RF filter band selector for CH1..CH8 via MCP23017 gpio-line-names
- Supports:
  (A) CLI mode: set bands by frequency then exit / or hold
  (B) WebSocket Server mode: JSON API for other apps to set channels independently

Band selection by frequency:
  B4:  freq < 108 MHz
  B3:  108 MHz <= freq < 140 MHz
  B2:  140 MHz <= freq <= 700 MHz
  B1:  freq > 700 MHz

Your wiring:
  IN  switch U8:  B1->RF4, B2->RF3, B3->RF2, B4->RF1
  OUT switch U7:  B1->RF1, B2->RF2, B3->RF3, B4->RF4

PE42442 truth table is given as (V2,V1) in datasheet; we use (V1,V2):
  RF1: V2=0 V1=1 => (V1,V2)=(1,0)
  RF2: V2=1 V1=0 => (0,1)
  RF3: V2=1 V1=1 => (1,1)
  RF4: V2=0 V1=0 => (0,0)

GPIO line names required (from device-tree gpio-line-names):
  RFx_IN_V1, RFx_IN_V2, RFx_OUT_V1, RFx_OUT_V2  (x=1..8)

WebSocket JSON API (text frames):
  - Get status:
      {"cmd":"get"}
  - Set frequency for channels:
      {"cmd":"set_freq","channels":[1,2,3,4,5],"freq_hz":118000000,"client":"df"}
      {"cmd":"set_freq","channels":[7],"freq_hz":450000000,"client":"scanner"}
  - Set band directly:
      {"cmd":"set_band","channels":[7],"band":"B2","client":"scanner"}
  - Convenience: set DF common for CH1-5:
      {"cmd":"set_df_common","freq_hz":118000000,"client":"df"}
  - Convenience: set per-channel map:
      {"cmd":"set_map","freq_map":{"1":118000000,"2":118000000,"7":450000000},"client":"any"}

Responses (always JSON):
  {"ok":true,"cmd":"...","result":{...}}
  {"ok":false,"error":"...","detail":{...}}

Notes:
  - "input/output" in gpioinfo is not your RF direction; it's kernel GPIO direction.
  - This server requests lines as OUTPUT and holds them (values stay applied).

Dependencies:
  - python gpiod bindings (system: python3-libgpiod recommended)
  - websockets (pip install websockets) for WS server mode
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from dataclasses import dataclass
from typing import Dict, Tuple, Optional, Iterable, Any, List, Set

# ---- gpiod ----
try:
    import gpiod
    from gpiod.line import Direction, Value
except Exception as e:
    raise SystemExit(
        "Missing python gpiod bindings.\n"
        "Install (system): python3-libgpiod (recommended) or python3-gpiod\n"
        f"Error: {e}"
    )

# ---- websockets optional ----
_WEBSOCKETS_OK = True
try:
    import websockets
    from websockets.server import WebSocketServerProtocol
except Exception:
    _WEBSOCKETS_OK = False


# ===================== Band logic =====================

def band_from_frequency(freq_hz: int) -> str:
    if freq_hz < 108_000_000:
        return "B4"
    elif freq_hz < 140_000_000:
        return "B3"
    elif freq_hz <= 700_000_000:
        return "B2"
    else:
        return "B1"


# ===================== Your wiring: BAND -> PORT =====================

IN_BAND_TO_PORT = {
    "B1": "RF4",
    "B2": "RF3",
    "B3": "RF2",
    "B4": "RF1",
}

OUT_BAND_TO_PORT = {
    "B1": "RF1",
    "B2": "RF2",
    "B3": "RF3",
    "B4": "RF4",
}

# ===================== PE42442 PORT -> (V1,V2) =====================

PORT_TO_VBITS: Dict[str, Tuple[int, int]] = {
    "RF1": (1, 0),
    "RF2": (0, 1),
    "RF3": (1, 1),
    "RF4": (0, 0),
}

VALID_BANDS = {"B1", "B2", "B3", "B4"}
VALID_PORTS = {"RF1", "RF2", "RF3", "RF4"}


# ===================== Channel label mapping =====================

@dataclass(frozen=True)
class ChannelLines:
    in_v1: str
    in_v2: str
    out_v1: str
    out_v2: str

CHANNELS: Dict[int, ChannelLines] = {
    1: ChannelLines("RF1_IN_V1", "RF1_IN_V2", "RF1_OUT_V1", "RF1_OUT_V2"),
    2: ChannelLines("RF2_IN_V1", "RF2_IN_V2", "RF2_OUT_V1", "RF2_OUT_V2"),
    3: ChannelLines("RF3_IN_V1", "RF3_IN_V2", "RF3_OUT_V1", "RF3_OUT_V2"),
    4: ChannelLines("RF4_IN_V1", "RF4_IN_V2", "RF4_OUT_V1", "RF4_OUT_V2"),
    5: ChannelLines("RF5_IN_V1", "RF5_IN_V2", "RF5_OUT_V1", "RF5_OUT_V2"),
    6: ChannelLines("RF6_IN_V1", "RF6_IN_V2", "RF6_OUT_V1", "RF6_OUT_V2"),
    7: ChannelLines("RF7_IN_V1", "RF7_IN_V2", "RF7_OUT_V1", "RF7_OUT_V2"),
    8: ChannelLines("RF8_IN_V1", "RF8_IN_V2", "RF8_OUT_V1", "RF8_OUT_V2"),
}


# ===================== GPIO helpers =====================

def iter_gpiochips(max_chips: int = 128) -> Iterable[str]:
    for n in range(max_chips):
        path = f"/dev/gpiochip{n}"
        if os.path.exists(path):
            yield path

def find_line_by_name(target_name: str, max_chips: int = 128) -> Tuple[str, int]:
    for chip_path in iter_gpiochips(max_chips=max_chips):
        try:
            chip = gpiod.Chip(chip_path)
        except Exception:
            continue
        try:
            info = chip.get_info()
            for offset in range(info.num_lines):
                li = chip.get_line_info(offset)
                if li.name == target_name:
                    return chip_path, offset
        finally:
            try:
                chip.close()
            except Exception:
                pass
    raise RuntimeError(f"GPIO line name not found: {target_name}")


# ===================== Core controller =====================

@dataclass
class AppliedState:
    ch: int
    band: str
    freq_hz: Optional[int]
    in_port: str
    out_port: str
    in_v1: int
    in_v2: int
    out_v1: int
    out_v2: int
    updated_ms: int
    client: str

class RFBandController:
    """
    Requests GPIO lines as OUTPUT and holds them (values stay applied).
    Uses line "names" (labels) instead of hardcoding chip numbers.
    """

    def __init__(self, dry_run: bool = False, verbose: bool = True):
        self.dry_run = dry_run
        self.verbose = verbose

        self._chips: Dict[str, gpiod.Chip] = {}
        self._requests: Dict[str, gpiod.LineRequest] = {}
        self._loc: Dict[str, Tuple[str, int]] = {}

        # last applied state per channel
        self.state: Dict[int, AppliedState] = {}

        # asyncio lock per channel to allow independent control (no cross-channel blocking)
        self._locks: Dict[int, asyncio.Lock] = {ch: asyncio.Lock() for ch in CHANNELS.keys()}

    def locate(self, line_name: str) -> Tuple[str, int]:
        if line_name not in self._loc:
            self._loc[line_name] = find_line_by_name(line_name)
        return self._loc[line_name]

    def prime(self):
        """Discover and request all control lines (IN/OUT V1/V2 for CH1..CH8)."""
        all_names: List[str] = []
        for ch in sorted(CHANNELS.keys()):
            ln = CHANNELS[ch]
            all_names.extend([ln.in_v1, ln.in_v2, ln.out_v1, ln.out_v2])

        by_chip: Dict[str, set] = {}
        for name in all_names:
            chip_path, off = self.locate(name)
            by_chip.setdefault(chip_path, set()).add(off)

        for chip_path, offs in by_chip.items():
            self._ensure_request(chip_path, tuple(sorted(offs)))

    def _ensure_request(self, chip_path: str, offsets: Tuple[int, ...]) -> Optional[gpiod.LineRequest]:
        if chip_path in self._requests:
            return self._requests[chip_path]

        if self.dry_run:
            return None

        chip = gpiod.Chip(chip_path)
        self._chips[chip_path] = chip

        settings = gpiod.LineSettings(direction=Direction.OUTPUT, output_value=Value.INACTIVE)
        req = chip.request_lines(
            consumer="rf_band_select",
            config={off: settings for off in offsets},
        )
        self._requests[chip_path] = req
        return req

    async def set_channel_freq(self, ch: int, freq_hz: int, client: str = "unknown") -> AppliedState:
        band = band_from_frequency(freq_hz)
        return await self.set_channel_band(ch, band, freq_hz=freq_hz, client=client)

    async def set_channel_band(self, ch: int, band: str, freq_hz: Optional[int] = None, client: str = "unknown") -> AppliedState:
        if ch not in CHANNELS:
            raise ValueError(f"Invalid channel: {ch}")
        if band not in VALID_BANDS:
            raise ValueError(f"Invalid band: {band}")

        async with self._locks[ch]:
            in_port = IN_BAND_TO_PORT[band]
            out_port = OUT_BAND_TO_PORT[band]

            if in_port not in VALID_PORTS or out_port not in VALID_PORTS:
                raise ValueError(f"Bad port mapping for band {band}: in={in_port} out={out_port}")

            in_v1, in_v2 = PORT_TO_VBITS[in_port]
            out_v1, out_v2 = PORT_TO_VBITS[out_port]

            ln = CHANNELS[ch]
            # Apply IN switch
            self._set_named_line(ln.in_v1, in_v1)
            self._set_named_line(ln.in_v2, in_v2)
            # Apply OUT switch
            self._set_named_line(ln.out_v1, out_v1)
            self._set_named_line(ln.out_v2, out_v2)

            st = AppliedState(
                ch=ch,
                band=band,
                freq_hz=freq_hz,
                in_port=in_port,
                out_port=out_port,
                in_v1=in_v1, in_v2=in_v2,
                out_v1=out_v1, out_v2=out_v2,
                updated_ms=int(time.time() * 1000),
                client=client,
            )
            self.state[ch] = st
            if self.verbose:
                print(f"[APPLY] ch={ch} band={band} freq={freq_hz} in={in_port}({in_v1},{in_v2}) out={out_port}({out_v1},{out_v2}) client={client}")
            return st

    async def set_channels_freq(self, channels: List[int], freq_hz: int, client: str = "unknown") -> List[AppliedState]:
        # set sequentially to keep output readable and deterministic
        out: List[AppliedState] = []
        for ch in channels:
            out.append(await self.set_channel_freq(ch, freq_hz, client=client))
        return out

    async def set_channels_band(self, channels: List[int], band: str, client: str = "unknown") -> List[AppliedState]:
        out: List[AppliedState] = []
        for ch in channels:
            out.append(await self.set_channel_band(ch, band, freq_hz=None, client=client))
        return out

    async def set_df_common(self, freq_hz: int, client: str = "df") -> List[AppliedState]:
        return await self.set_channels_freq([1, 2, 3, 4, 5, 8], freq_hz, client=client)

    async def set_map(self, freq_map: Dict[int, int], client: str = "unknown") -> List[AppliedState]:
        out: List[AppliedState] = []
        for ch, f in freq_map.items():
            out.append(await self.set_channel_freq(ch, f, client=client))
        return out

    def _set_named_line(self, line_name: str, value01: int):
        chip_path, off = self.locate(line_name)
        if self.dry_run:
            return

        req = self._requests.get(chip_path)
        if req is None:
            self._ensure_request(chip_path, (off,))
            req = self._requests[chip_path]

        req.set_value(off, Value.ACTIVE if value01 else Value.INACTIVE)

    def probe(self) -> Dict[str, Dict[str, int]]:
        mp: Dict[str, Dict[str, int]] = {}
        for ch in sorted(CHANNELS.keys()):
            ln = CHANNELS[ch]
            for nm in (ln.in_v1, ln.in_v2, ln.out_v1, ln.out_v2):
                chip_path, off = self.locate(nm)
                mp[nm] = {"chip": int(os.path.basename(chip_path).replace("gpiochip", "")), "offset": off}
        return mp

    def close(self):
        if self.dry_run:
            return
        for req in self._requests.values():
            try:
                req.release()
            except Exception:
                pass
        for chip in self._chips.values():
            try:
                chip.close()
            except Exception:
                pass


# ===================== WebSocket Server =====================

class WSServer:
    def __init__(self, ctl: RFBandController, host: str, port: int, verbose: bool = True):
        self.ctl = ctl
        self.host = host
        self.port = port
        self.verbose = verbose
        self.clients: Set[WebSocketServerProtocol] = set()

    def _state_json(self) -> Dict[str, Any]:
        return {
            "channels": {
                str(ch): {
                    "band": st.band,
                    "freq_hz": st.freq_hz,
                    "in_port": st.in_port,
                    "out_port": st.out_port,
                    "in_v1": st.in_v1,
                    "in_v2": st.in_v2,
                    "out_v1": st.out_v1,
                    "out_v2": st.out_v2,
                    "updated_ms": st.updated_ms,
                    "client": st.client,
                }
                for ch, st in self.ctl.state.items()
            }
        }

    async def _broadcast_state(self):
        if not self.clients:
            return
        msg = json.dumps({"event": "state", "data": self._state_json()}, separators=(",", ":"))
        dead: List[WebSocketServerProtocol] = []
        for ws in self.clients:
            try:
                await ws.send(msg)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.clients.discard(ws)

    async def handle(self, ws: WebSocketServerProtocol):
        self.clients.add(ws)
        if self.verbose:
            print(f"[WS] client connected ({len(self.clients)})")

        # send hello + current state
        await ws.send(json.dumps({
            "event": "hello",
            "api": "rf_band_select_ws_v1",
            "state": self._state_json(),
        }, separators=(",", ":")))

        try:
            async for text in ws:
                try:
                    req = json.loads(text)
                except Exception:
                    await ws.send(json.dumps({"ok": False, "error": "bad_json"}, separators=(",", ":")))
                    continue

                resp = await self._dispatch(req)
                await ws.send(json.dumps(resp, separators=(",", ":")))

                # broadcast latest state after any successful set
                if resp.get("ok") and req.get("cmd", "").startswith("set"):
                    await self._broadcast_state()

        except Exception as e:
            if self.verbose:
                print(f"[WS] client error: {e}")
        finally:
            self.clients.discard(ws)
            if self.verbose:
                print(f"[WS] client disconnected ({len(self.clients)})")

    async def _dispatch(self, req: Dict[str, Any]) -> Dict[str, Any]:
        cmd = str(req.get("cmd", "")).strip()
        client = str(req.get("client", "unknown"))[:64]

        try:
            if cmd == "get":
                return {"ok": True, "cmd": "get", "result": self._state_json()}

            if cmd == "probe":
                return {"ok": True, "cmd": "probe", "result": self.ctl.probe()}

            if cmd == "set_df_common":
                freq_hz = int(req["freq_hz"])
                res = await self.ctl.set_df_common(freq_hz, client=client)
                return {"ok": True, "cmd": cmd, "result": [st.__dict__ for st in res]}

            if cmd == "set_freq":
                channels = [int(x) for x in req["channels"]]
                freq_hz = int(req["freq_hz"])
                _validate_channels(channels)
                res = await self.ctl.set_channels_freq(channels, freq_hz, client=client)
                return {"ok": True, "cmd": cmd, "result": [st.__dict__ for st in res]}

            if cmd == "set_band":
                channels = [int(x) for x in req["channels"]]
                band = str(req["band"]).strip().upper()
                _validate_channels(channels)
                _validate_band(band)
                res = await self.ctl.set_channels_band(channels, band, client=client)
                return {"ok": True, "cmd": cmd, "result": [st.__dict__ for st in res]}

            if cmd == "set_map":
                freq_map_in = req["freq_map"]
                if not isinstance(freq_map_in, dict):
                    raise ValueError("freq_map must be object")
                freq_map: Dict[int, int] = {int(k): int(v) for k, v in freq_map_in.items()}
                _validate_channels(list(freq_map.keys()))
                res = await self.ctl.set_map(freq_map, client=client)
                return {"ok": True, "cmd": cmd, "result": [st.__dict__ for st in res]}

            return {"ok": False, "error": "unknown_cmd", "detail": {"cmd": cmd}}

        except KeyError as e:
            return {"ok": False, "error": "missing_field", "detail": {"missing": str(e)}}
        except Exception as e:
            return {"ok": False, "error": "bad_request", "detail": {"message": str(e), "cmd": cmd}}

    async def run(self):
        if not _WEBSOCKETS_OK:
            raise SystemExit("Missing websockets package. Install in venv: pip install websockets")

        if self.verbose:
            print(f"[WS] starting on {self.host}:{self.port}")

        async with websockets.serve(self.handle, self.host, self.port, max_size=2 * 1024 * 1024):
            while True:
                await asyncio.sleep(3600)


def _validate_channels(channels: List[int]):
    for ch in channels:
        if ch not in CHANNELS:
            raise ValueError(f"Invalid channel: {ch}")

def _validate_band(band: str):
    if band not in VALID_BANDS:
        raise ValueError(f"Invalid band: {band}")


# ===================== CLI parse =====================

def parse_freq_str(s: Optional[str]) -> Optional[int]:
    if s is None:
        return None
    s = s.strip().lower()
    try:
        return int(float(s))
    except ValueError:
        pass
    try:
        return int(float(eval(s, {"__builtins__": {}}, {})))  # allow 118e6
    except Exception:
        raise argparse.ArgumentTypeError(f"Bad frequency: {s}")

def mhz_to_hz(mhz: Optional[float]) -> Optional[int]:
    if mhz is None:
        return None
    return int(round(float(mhz) * 1_000_000))


def main():
    ap = argparse.ArgumentParser(description="RF Band selector + WebSocket server")
    ap.add_argument("--dry-run", action="store_true", help="Do not set GPIO, just print")
    ap.add_argument("--quiet", action="store_true", help="Less output")
    ap.add_argument("--probe", action="store_true", help="Probe label -> (chip,offset) then exit")

    # CLI set mode (optional)
    ap.add_argument("--common", type=str, help="Common frequency (Hz) for CH1-5, e.g. 118e6")
    ap.add_argument("--common-mhz", type=float, help="Common frequency (MHz) for CH1-5")
    ap.add_argument("--ch6", type=str, help="CH6 frequency (Hz)")
    ap.add_argument("--ch7", type=str, help="CH7 frequency (Hz)")
    ap.add_argument("--ch8", type=str, help="CH8 frequency (Hz)")
    ap.add_argument("--hold", action="store_true", help="Hold GPIO lines (keep process running)")

    # WebSocket server mode
    ap.add_argument("--ws", action="store_true", help="Run as WebSocket server")
    ap.add_argument("--host", type=str, default="0.0.0.0", help="WebSocket bind host")
    ap.add_argument("--port", type=int, default=8765, help="WebSocket port")

    args = ap.parse_args()

    if os.geteuid() != 0:
        print("WARNING: Not running as root. Use sudo for GPIO access.\n", file=sys.stderr)

    verbose = not args.quiet
    ctl = RFBandController(dry_run=args.dry_run, verbose=verbose)

    try:
        ctl.prime()

        if args.probe:
            mp = ctl.probe()
            print(json.dumps(mp, indent=2))
            return

        # WebSocket server
        if args.ws:
            srv = WSServer(ctl, host=args.host, port=args.port, verbose=verbose)
            asyncio.run(srv.run())
            return

        # CLI set mode (optional)
        common_hz = None
        if args.common is not None:
            common_hz = parse_freq_str(args.common)
        if args.common_mhz is not None:
            common_hz = mhz_to_hz(args.common_mhz)

        ch6_hz = parse_freq_str(args.ch6) if args.ch6 else None
        ch7_hz = parse_freq_str(args.ch7) if args.ch7 else None
        ch8_hz = parse_freq_str(args.ch8) if args.ch8 else None

        if common_hz is None:
            print("No --ws and no --common provided. Nothing to do.\nTry: --ws  OR  --common 118e6", file=sys.stderr)
            return

        async def _apply():
            await ctl.set_df_common(common_hz, client="cli")
            if ch6_hz is not None:
                await ctl.set_channel_freq(6, ch6_hz, client="cli")
            if ch7_hz is not None:
                await ctl.set_channel_freq(7, ch7_hz, client="cli")
            if ch8_hz is not None:
                await ctl.set_channel_freq(8, ch8_hz, client="cli")

        asyncio.run(_apply())

        if args.hold:
            print("Holding GPIO lines. Ctrl+C to exit.")
            while True:
                time.sleep(1)

    finally:
        ctl.close()


if __name__ == "__main__":
    main()

